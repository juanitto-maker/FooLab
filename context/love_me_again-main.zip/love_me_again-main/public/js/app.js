// Shared utilities

async function apiFetch(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers
    }
  });
  if (!response.ok) {
    const err = await response.json().catch(() => ({ error: 'Request failed' }));
    throw new Error(err.error || 'Request failed');
  }
  return response.json();
}

function formatPrice(price) {
  if (price == null) return '—';
  return '€' + Number(price).toFixed(2);
}

function formatCondition(condition) {
  return t('condition_' + condition) || condition;
}

function formatConfidence(confidence) {
  return t('confidence_' + confidence) || confidence;
}

function compressImage(file, maxWidth = 800, quality = 0.7) {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        let w = img.width;
        let h = img.height;

        if (w > maxWidth) {
          h = (h * maxWidth) / w;
          w = maxWidth;
        }

        canvas.width = w;
        canvas.height = h;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, w, h);

        const dataUrl = canvas.toDataURL('image/jpeg', quality);
        const base64 = dataUrl.split(',')[1];
        resolve(base64);
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

// === Price Badge System ===
const DEFAULT_PRICE_BADGES = [
  { color: 'green', emoji: '💚', min: 0, max: 5 },
  { color: 'blue', emoji: '💙', min: 5, max: 10 },
  { color: 'orange', emoji: '🧡', min: 10, max: 20 },
  { color: 'red', emoji: '❤️', min: 20, max: null }
];

let priceBadgesConfig = DEFAULT_PRICE_BADGES;

async function loadPriceBadges() {
  try {
    const data = await apiFetch('/api/badges');
    priceBadgesConfig = data.badges || DEFAULT_PRICE_BADGES;
  } catch (e) {
    priceBadgesConfig = DEFAULT_PRICE_BADGES;
  }
  return priceBadgesConfig;
}

function getPriceBadge(price) {
  if (price == null) return null;
  const p = Number(price);
  for (const b of priceBadgesConfig) {
    if (p >= b.min && (b.max === null || p < b.max)) {
      return b;
    }
  }
  return null;
}

function priceBadgeHtml(price) {
  const badge = getPriceBadge(price);
  if (!badge) return '';
  return `<span class="price-badge price-badge-${badge.color}" title="${badge.emoji}">${badge.emoji}</span>`;
}

// Register service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(() => {});
  });
}

// === PWA Install Prompt ===
let deferredInstallPrompt = null;

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredInstallPrompt = e;
  const btn = document.getElementById('installBtn');
  if (btn) btn.style.display = 'flex';
});

window.addEventListener('appinstalled', () => {
  deferredInstallPrompt = null;
  const btn = document.getElementById('installBtn');
  if (btn) btn.style.display = 'none';
});

// Hide install button if already running as installed PWA
if (window.matchMedia('(display-mode: standalone)').matches || navigator.standalone) {
  document.addEventListener('DOMContentLoaded', () => {
    const btn = document.getElementById('installBtn');
    if (btn) btn.style.display = 'none';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  // Install button handler
  const installBtn = document.getElementById('installBtn');
  if (installBtn) {
    installBtn.addEventListener('click', async () => {
      if (!deferredInstallPrompt) return;
      deferredInstallPrompt.prompt();
      const result = await deferredInstallPrompt.userChoice;
      if (result.outcome === 'accepted') {
        deferredInstallPrompt = null;
        installBtn.style.display = 'none';
      }
    });
  }

  // Share button handler
  const shareBtn = document.getElementById('shareBtn');
  if (shareBtn) {
    shareBtn.addEventListener('click', async () => {
      const shareData = {
        title: 'Love Me Again — Rastro Solidario',
        text: t('shareText'),
        url: window.location.origin
      };
      if (navigator.share) {
        try {
          await navigator.share(shareData);
        } catch (e) {
          // User cancelled or share failed — ignore
        }
      } else {
        // Fallback: copy URL to clipboard
        try {
          await navigator.clipboard.writeText(window.location.origin);
          shareBtn.title = t('linkCopied');
          setTimeout(() => { shareBtn.title = t('share'); }, 2000);
        } catch (e) {
          // Ignore
        }
      }
    });
  }
});
