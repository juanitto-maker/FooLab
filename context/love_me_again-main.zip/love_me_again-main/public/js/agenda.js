// Shared logic for /workshops and /events pages.
// Reads window.AGENDA_KIND ('workshop' | 'event') to pick the data source.
(function() {
  const KIND = window.AGENDA_KIND || 'event';
  const limit = 20;

  // Sentinel date (UTC year 9999) marks entries whose start date is TBD.
  function isComingSoonIso(iso) {
    if (!iso) return false;
    const d = new Date(iso);
    return !isNaN(d) && d.getUTCFullYear() === 9999;
  }

  let currentTab = 'upcoming';
  let upcomingOffset = 0;
  let pastOffset = 0;
  let upcomingTotal = 0;
  let pastTotal = 0;
  let isVolunteer = !!localStorage.getItem('volunteer_pin');
  let currentModalEvent = null;
  let deleteEventId = null;
  let photoSwipeInstance = null;

  const loading = document.getElementById('loading');
  const upcomingSection = document.getElementById('upcomingSection');
  const upcomingGrid = document.getElementById('upcomingGrid');
  const upcomingLoadMore = document.getElementById('upcomingLoadMore');
  const upcomingLoadMoreBtn = document.getElementById('upcomingLoadMoreBtn');
  const upcomingEmpty = document.getElementById('upcomingEmpty');
  const pastSection = document.getElementById('pastSection');
  const pastGrid = document.getElementById('pastGrid');
  const pastLoadMore = document.getElementById('pastLoadMore');
  const pastLoadMoreBtn = document.getElementById('pastLoadMoreBtn');
  const pastEmpty = document.getElementById('pastEmpty');
  const modal = document.getElementById('eventModal');
  const modalClose = document.getElementById('modalClose');
  const modalActions = document.getElementById('modalActions');
  const modalDeleteBtn = document.getElementById('modalDeleteBtn');
  const modalEditBtn = document.getElementById('modalEditBtn');
  const deleteModal = document.getElementById('deleteModal');
  const deleteCancelBtn = document.getElementById('deleteCancelBtn');
  const deleteConfirmBtn = document.getElementById('deleteConfirmBtn');
  const sectionTabs = document.getElementById('sectionTabs');

  window.reloadTranslatedItems = async function() {
    upcomingOffset = 0;
    pastOffset = 0;
    upcomingGrid.innerHTML = '';
    pastGrid.innerHTML = '';
    await loadTab(currentTab);
  };

  document.addEventListener('DOMContentLoaded', async () => {
    await initLanguage();
    setupTabs();
    setupModal();
    setupDelete();
    loadPhotoSwipe();
    loadTab('upcoming');
  });

  function loadPhotoSwipe() {
    // Dynamically import the ESM build of PhotoSwipe from CDN
    import('https://cdn.jsdelivr.net/npm/photoswipe@5.4.4/dist/photoswipe.esm.js')
      .then(mod => { window.__PhotoSwipe = mod.default || mod; })
      .catch(err => console.warn('PhotoSwipe load failed:', err));
  }

  function setupTabs() {
    sectionTabs.addEventListener('click', (e) => {
      const tab = e.target.closest('.section-tab');
      if (!tab) return;
      const section = tab.dataset.section;
      if (section === currentTab) return;
      sectionTabs.querySelectorAll('.section-tab').forEach(x => x.classList.remove('active'));
      tab.classList.add('active');
      currentTab = section;
      if (section === 'upcoming') {
        upcomingSection.style.display = '';
        pastSection.style.display = 'none';
        if (upcomingGrid.children.length === 0) loadTab('upcoming');
      } else {
        upcomingSection.style.display = 'none';
        pastSection.style.display = '';
        if (pastGrid.children.length === 0) loadTab('past');
      }
    });
  }

  function setupModal() {
    modalClose.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });
    modalDeleteBtn.addEventListener('click', () => {
      if (!currentModalEvent) return;
      deleteEventId = currentModalEvent.id;
      deleteModal.style.display = 'flex';
    });
    modalEditBtn.addEventListener('click', () => {
      if (!currentModalEvent) return;
      localStorage.setItem('agenda_edit_id', currentModalEvent.id);
      window.location.href = '/volunteer#agenda';
    });
    const modalShareBtn = document.getElementById('modalShareBtn');
    if (modalShareBtn) {
      modalShareBtn.addEventListener('click', () => {
        if (!currentModalEvent) return;
        shareEvent(currentModalEvent, modalShareBtn);
      });
    }
  }

  function setupDelete() {
    deleteCancelBtn.addEventListener('click', () => {
      deleteModal.style.display = 'none';
      deleteEventId = null;
    });
    deleteConfirmBtn.addEventListener('click', async () => {
      if (!deleteEventId) return;
      deleteConfirmBtn.disabled = true;
      try {
        await apiFetch('/api/event', {
          method: 'DELETE',
          body: JSON.stringify({ id: deleteEventId })
        });
        deleteModal.style.display = 'none';
        closeModal();
        reloadAll();
      } catch (err) {
        alert(err.message || t('deleteFailed'));
      } finally {
        deleteConfirmBtn.disabled = false;
        deleteEventId = null;
      }
    });
  }

  function closeModal() {
    modal.style.display = 'none';
    // Stop any playing video iframe by clearing it
    const videoEl = document.getElementById('modalVideo');
    if (videoEl) videoEl.innerHTML = '';
    currentModalEvent = null;
  }

  function reloadAll() {
    upcomingOffset = 0;
    pastOffset = 0;
    upcomingGrid.innerHTML = '';
    pastGrid.innerHTML = '';
    loadTab(currentTab);
  }

  async function loadTab(tab) {
    const isPast = tab === 'past';
    const grid = isPast ? pastGrid : upcomingGrid;
    const emptyEl = isPast ? pastEmpty : upcomingEmpty;
    const loadMoreEl = isPast ? pastLoadMore : upcomingLoadMore;
    loading.style.display = '';
    emptyEl.style.display = 'none';
    try {
      const data = await fetchEvents(tab);
      data.events.forEach(ev => grid.appendChild(createEventCard(ev, tab)));
      if (isPast) {
        pastTotal = data.total;
        pastOffset += data.events.length;
      } else {
        upcomingTotal = data.total;
        upcomingOffset += data.events.length;
      }
      loading.style.display = 'none';
      const total = isPast ? pastTotal : upcomingTotal;
      const offset = isPast ? pastOffset : upcomingOffset;
      if (grid.children.length === 0 && total === 0) emptyEl.style.display = '';
      loadMoreEl.style.display = offset < total ? '' : 'none';
    } catch (err) {
      console.error('Failed to load events:', err);
      loading.style.display = 'none';
    }
  }

  async function fetchEvents(tab) {
    const offset = tab === 'past' ? pastOffset : upcomingOffset;
    const params = new URLSearchParams({
      kind: KIND,
      when: tab,
      limit: String(limit),
      offset: String(offset)
    });
    try {
      const data = await apiFetch('/api/events?' + params);
      if (typeof translateEvents === 'function' && Array.isArray(data.events)) {
        data.events = await translateEvents(data.events, getCurrentLang());
      }
      return data;
    } catch (err) {
      console.error('fetchEvents failed:', err);
      return { events: [], total: 0 };
    }
  }

  if (upcomingLoadMoreBtn) {
    upcomingLoadMoreBtn.addEventListener('click', () => loadTab('upcoming'));
  }
  if (pastLoadMoreBtn) {
    pastLoadMoreBtn.addEventListener('click', () => loadTab('past'));
  }

  function formatDate(iso) {
    if (!iso) return '';
    if (isComingSoonIso(iso)) return t('comingSoon');
    try {
      const d = new Date(iso);
      const lang = getCurrentLang();
      return d.toLocaleDateString(lang, { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' })
        + ' · ' + d.toLocaleTimeString(lang, { hour: '2-digit', minute: '2-digit' });
    } catch (e) {
      return iso;
    }
  }

  function createEventCard(ev, tab) {
    const card = document.createElement('div');
    const isPast = tab === 'past';
    card.className = 'event-card' + (isPast ? ' event-card-past' : '');
    card.dataset.eventId = ev.id;

    const photos = Array.isArray(ev.photo_urls) ? ev.photo_urls : [];
    const cover = photos[0] || '';
    const priceText = ev.price_eur == null ? t('free') : ('€' + Number(ev.price_eur).toFixed(2));
    const videoBadge = ev.video_url ? `<span class="event-card-video-badge" title="Video">&#x25B6;&#xFE0F;</span>` : '';

    card.innerHTML = `
      <div class="event-card-img-wrap">
        ${cover
          ? `<img class="event-card-img" src="${escapeHtml(cover)}" alt="${escapeHtml(ev.title)}" loading="lazy">`
          : `<div class="event-card-img event-card-img-placeholder">${KIND === 'workshop' ? '&#x1F3A8;' : '&#x1F4C5;'}</div>`}
        ${videoBadge}
        ${photos.length > 1 ? `<span class="event-card-photo-count">&#x1F5BC;&#xFE0F; ${photos.length}</span>` : ''}
      </div>
      <div class="event-card-body">
        <div class="event-card-title">${escapeHtml(ev.title)}</div>
        <div class="event-card-date">${escapeHtml(formatDate(ev.starts_at))}</div>
        ${ev.location ? `<div class="event-card-location">&#x1F4CD; ${escapeHtml(ev.location)}</div>` : ''}
        <div class="event-card-footer">
          <span class="event-card-price">${escapeHtml(priceText)}</span>
          <div class="event-card-footer-right">
            ${ev.capacity ? `<span class="event-card-capacity">&#x1F465; ${ev.capacity}</span>` : ''}
            <button class="share-btn" title="${t('share')}">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
            </button>
          </div>
        </div>
      </div>
    `;

    card.addEventListener('click', (e) => {
      if (e.target.closest('.share-btn')) return;
      openEventModal(ev);
    });

    const shareBtn = card.querySelector('.share-btn');
    if (shareBtn) {
      shareBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        shareEvent(ev, shareBtn);
      });
    }

    return card;
  }

  function shareEvent(ev, btn) {
    const basePath = KIND === 'workshop' ? '/workshops/' : '/events/';
    const shareUrl = window.location.origin + basePath + ev.id;
    const priceText = ev.price_eur == null ? t('free') : ('€' + Number(ev.price_eur).toFixed(2));
    const dateText = formatDate(ev.starts_at);
    const textParts = [ev.title];
    if (dateText) textParts.push(dateText);
    if (priceText) textParts.push(priceText);
    const shareData = {
      title: ev.title || '',
      text: textParts.filter(Boolean).join(' · '),
      url: shareUrl
    };
    if (navigator.share) {
      navigator.share(shareData).catch(() => {});
    } else if (navigator.clipboard) {
      navigator.clipboard.writeText(shareUrl).then(() => {
        btn.classList.add('share-btn-copied');
        setTimeout(() => btn.classList.remove('share-btn-copied'), 1500);
      }).catch(() => {});
    }
  }

  function openEventModal(ev) {
    currentModalEvent = ev;
    document.getElementById('modalTitle').textContent = ev.title;
    const dateText = isComingSoonIso(ev.starts_at)
      ? formatDate(ev.starts_at)
      : formatDate(ev.starts_at) + (ev.ends_at ? ' → ' + formatDate(ev.ends_at) : '');
    document.getElementById('modalDate').textContent = dateText;

    const locEl = document.getElementById('modalLocation');
    if (ev.location) {
      locEl.textContent = '📍 ' + ev.location;
      locEl.style.display = '';
    } else {
      locEl.style.display = 'none';
    }

    renderModalBadges(ev);
    renderModalGallery(Array.isArray(ev.photo_urls) ? ev.photo_urls : []);
    renderModalVideo(ev.video_url);

    document.getElementById('modalDescription').textContent = ev.description || '';
    renderModalDetails(ev);

    modalActions.style.display = isVolunteer ? '' : 'none';

    modal.style.display = 'flex';
  }

  function renderModalBadges(ev) {
    const container = document.getElementById('modalBadges');
    const price = ev.price_eur == null ? t('free') : ('€' + Number(ev.price_eur).toFixed(2));
    const badges = [`<span class="badge">${escapeHtml(price)}</span>`];
    if (ev.capacity) badges.push(`<span class="badge">👥 ${ev.capacity}</span>`);
    if (ev.organizer) badges.push(`<span class="badge">${escapeHtml(ev.organizer)}</span>`);
    container.innerHTML = badges.join('');
  }

  function renderModalDetails(ev) {
    const container = document.getElementById('modalDetails');
    const rows = [];
    if (ev.requirements) rows.push(detailRow(t('requirements'), ev.requirements));
    if (ev.contact) rows.push(detailRow(t('contact'), linkify(ev.contact)));
    container.innerHTML = rows.join('');
  }

  function detailRow(label, value) {
    return `<div class="event-detail-row"><span class="event-detail-label">${escapeHtml(label)}</span><span class="event-detail-value">${value}</span></div>`;
  }

  function linkify(text) {
    const escaped = escapeHtml(text);
    const urlRe = /(https?:\/\/\S+)/g;
    return escaped.replace(urlRe, url => `<a href="${url}" target="_blank" rel="noopener">${url}</a>`);
  }

  function renderModalGallery(photos) {
    const gallery = document.getElementById('modalGallery');
    gallery.innerHTML = '';
    if (!photos.length) {
      gallery.style.display = 'none';
      return;
    }
    gallery.style.display = '';
    gallery.dataset.pswpReady = '';

    photos.forEach((url, idx) => {
      const a = document.createElement('a');
      a.href = url;
      a.dataset.pswpWidth = '1600';
      a.dataset.pswpHeight = '1600';
      a.className = 'event-gallery-item';
      const img = document.createElement('img');
      img.src = url;
      img.alt = '';
      img.loading = 'lazy';
      a.appendChild(img);
      // Resolve natural dimensions to keep PhotoSwipe aspect correct
      img.addEventListener('load', () => {
        if (img.naturalWidth && img.naturalHeight) {
          a.dataset.pswpWidth = img.naturalWidth;
          a.dataset.pswpHeight = img.naturalHeight;
        }
      });
      a.addEventListener('click', (e) => {
        e.preventDefault();
        openPhotoSwipe(photos, idx);
      });
      gallery.appendChild(a);
    });
  }

  async function openPhotoSwipe(photos, startIndex) {
    const PhotoSwipe = window.__PhotoSwipe;
    if (!PhotoSwipe) {
      // Not yet loaded — fallback opens image in new tab
      window.open(photos[startIndex], '_blank');
      return;
    }
    if (photoSwipeInstance) {
      try { photoSwipeInstance.destroy(); } catch (e) {}
      photoSwipeInstance = null;
    }

    // Pre-resolve sizes so PhotoSwipe has accurate width/height for zoom
    const dataSource = await Promise.all(photos.map(url => new Promise(resolve => {
      const img = new Image();
      img.onload = () => resolve({ src: url, width: img.naturalWidth || 1600, height: img.naturalHeight || 1600 });
      img.onerror = () => resolve({ src: url, width: 1600, height: 1600 });
      img.src = url;
    })));

    photoSwipeInstance = new PhotoSwipe({
      dataSource,
      index: startIndex,
      showHideAnimationType: 'zoom',
      bgOpacity: 0.95,
      pinchToClose: true,
      closeOnVerticalDrag: true
    });
    photoSwipeInstance.init();
  }

  function renderModalVideo(videoUrl) {
    const wrap = document.getElementById('modalVideo');
    if (!videoUrl) { wrap.style.display = 'none'; wrap.innerHTML = ''; return; }
    const embed = videoEmbedHtml(videoUrl);
    if (embed) {
      wrap.innerHTML = embed;
      wrap.style.display = '';
    } else {
      wrap.innerHTML = `<a href="${escapeHtml(videoUrl)}" target="_blank" rel="noopener" class="event-video-link">&#x25B6;&#xFE0F; ${escapeHtml(videoUrl)}</a>`;
      wrap.style.display = '';
    }
  }

  function videoEmbedHtml(url) {
    const yt = parseYouTube(url);
    if (yt) {
      return `<div class="event-video-embed"><iframe src="https://www.youtube-nocookie.com/embed/${yt}?autoplay=1&mute=1&playsinline=1&rel=0" title="Video" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>`;
    }
    const vm = parseVimeo(url);
    if (vm) {
      return `<div class="event-video-embed"><iframe src="https://player.vimeo.com/video/${vm}?autoplay=1&muted=1&playsinline=1" title="Video" frameborder="0" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen></iframe></div>`;
    }
    return null;
  }

  function parseYouTube(url) {
    try {
      const u = new URL(url);
      if (u.hostname.includes('youtu.be')) {
        return u.pathname.replace('/', '').split('/')[0] || null;
      }
      if (u.hostname.includes('youtube.com') || u.hostname.includes('youtube-nocookie.com')) {
        if (u.pathname === '/watch') return u.searchParams.get('v');
        const m = u.pathname.match(/^\/(embed|shorts|v|live)\/([\w-]+)/);
        if (m) return m[2];
      }
    } catch (e) {}
    return null;
  }

  function parseVimeo(url) {
    try {
      const u = new URL(url);
      if (!u.hostname.includes('vimeo.com')) return null;
      const m = u.pathname.match(/\/(\d+)/);
      return m ? m[1] : null;
    } catch (e) { return null; }
  }

  function escapeHtml(str) {
    if (str == null) return '';
    const div = document.createElement('div');
    div.textContent = String(str);
    return div.innerHTML;
  }
})();
