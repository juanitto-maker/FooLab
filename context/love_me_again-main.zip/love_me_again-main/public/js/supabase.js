// Supabase client for public reads (anon key only)
// The anon key and URL are injected here — these are safe for client-side use
// They only allow reading public data via RLS policies

(function() {
  // These will be replaced with actual values when Supabase is configured
  // For now, they gracefully handle missing config
  const SUPABASE_URL = '';
  const SUPABASE_ANON_KEY = '';

  if (SUPABASE_URL && SUPABASE_ANON_KEY && window.supabase) {
    window.supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  } else {
    window.supabaseClient = null;
  }
})();
