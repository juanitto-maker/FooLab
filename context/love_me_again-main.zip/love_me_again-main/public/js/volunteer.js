// Volunteer pricing tool logic
(function() {
  const MAX_PHOTOS = 5;
  let currentPhotos = []; // array of base64 strings (no data:image/... prefix)
  let currentAnalysis = null;
  let pendingMaterialsData = null;
  let materialsTried = false;
  let categoriesCache = [];
  let deletingCategoryId = null;

  const pinScreen = document.getElementById('pinScreen');
  const skipAiBtn = document.getElementById('skipAiBtn');
  const analyzeBtn = document.getElementById('analyzeBtn');
  const manualPriceCard = document.getElementById('manualPriceCard');
  const manualSaveBtn = document.getElementById('manualSaveBtn');
  const manualCancelBtn = document.getElementById('manualCancelBtn');
  const manualConditionOptions = document.getElementById('manualConditionOptions');
  const retakeInput = document.getElementById('retakeInput');
  const mainScreen = document.getElementById('mainScreen');
  const pinInput = document.getElementById('pinInput');
  const pinSubmit = document.getElementById('pinSubmit');
  const pinError = document.getElementById('pinError');
  const cameraInput = document.getElementById('cameraInput');
  const galleryInput = document.getElementById('galleryInput');
  const photoStrip = document.getElementById('photoStrip');
  const photoCountHint = document.getElementById('photoCountHint');
  const analysisLoading = document.getElementById('analysisLoading');
  const multiSelect = document.getElementById('multiSelect');
  const multiList = document.getElementById('multiList');
  const materialsSection = document.getElementById('materialsSection');
  const materialsGrid = document.getElementById('materialsGrid');
  const conditionOptions = document.getElementById('conditionOptions');
  const priceCard = document.getElementById('priceCard');
  const saveSuccess = document.getElementById('saveSuccess');
  const saveItemBtn = document.getElementById('saveItemBtn');
  const discardBtn = document.getElementById('discardBtn');
  const newItemBtn = document.getElementById('newItemBtn');
  const todayList = document.getElementById('todayList');
  const estimateBtn = document.getElementById('estimateWithMaterialsBtn');
  const materialsCancelBtn = document.getElementById('materialsCancelBtn');

  // Expose reload hook for language switcher (i18n.js calls this on language change).
  // sessionStorage caches translations per session — no manual clearing needed.
  window.reloadTranslatedItems = async function() {
    await loadCategories();
    await loadTodayItems();
    renderBadgeRows();
    if (materialsSection.style.display !== 'none' && pendingMaterialsData) {
      showMaterialsSelection(pendingMaterialsData);
    }
  };

  document.addEventListener('DOMContentLoaded', async () => {
    await initLanguage();
    await loadPriceBadges();
    checkPin();
    setupEvents();
    setupCategoryManagement();
    setupBadgeManagement();
    loadCategories();
    loadTodayItems();
  });

  // === PIN ===
  function checkPin() {
    const savedPin = localStorage.getItem('volunteer_pin');
    if (savedPin) {
      pinScreen.style.display = 'none';
      mainScreen.style.display = '';
    }
  }

  function setupEvents() {
    pinSubmit.addEventListener('click', verifyPin);
    pinInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') verifyPin();
    });

    cameraInput.addEventListener('change', handleImageSelect);
    galleryInput.addEventListener('change', handleImageSelect);
    analyzeBtn.addEventListener('click', () => {
      if (currentPhotos.length > 0) analyzeImage();
    });
    saveItemBtn.addEventListener('click', saveItem);
    discardBtn.addEventListener('click', resetFlow);
    newItemBtn.addEventListener('click', resetFlow);
    estimateBtn.addEventListener('click', submitMaterials);
    materialsCancelBtn.addEventListener('click', resetFlow);
    document.getElementById('materialsManualBtn').addEventListener('click', () => {
      showManualPricing(pendingMaterialsData);
    });
    skipAiBtn.addEventListener('click', () => showManualPricing(null));
    manualSaveBtn.addEventListener('click', saveManualItem);
    manualCancelBtn.addEventListener('click', resetFlow);

    // Retake photo (extra photo) from materials screen — appends to existing photos
    retakeInput.addEventListener('change', async (e) => {
      const files = Array.from(e.target.files || []);
      if (!files.length) return;
      const slots = MAX_PHOTOS - currentPhotos.length;
      for (const file of files.slice(0, Math.max(slots, 1))) {
        const b64 = await compressImage(file);
        if (currentPhotos.length < MAX_PHOTOS) currentPhotos.push(b64);
      }
      renderPhotoStrip();
      materialsSection.style.display = 'none';
      e.target.value = '';
      analyzeImage();
    });

    // Condition button selection (both materials and manual forms)
    [conditionOptions, manualConditionOptions].forEach(container => {
      container.addEventListener('click', (e) => {
        const btn = e.target.closest('.filter-btn');
        if (!btn) return;
        container.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
      });
    });
  }

  async function verifyPin() {
    const pin = pinInput.value.trim();
    if (!pin) return;

    if (window.supabaseClient) {
      try {
        const { data } = await window.supabaseClient
          .from('config')
          .select('value')
          .eq('key', 'volunteer_pin')
          .single();

        if (data && data.value === pin) {
          localStorage.setItem('volunteer_pin', pin);
          pinScreen.style.display = 'none';
          mainScreen.style.display = '';
          pinError.style.display = 'none';
          return;
        }
      } catch (e) {
        localStorage.setItem('volunteer_pin', pin);
        pinScreen.style.display = 'none';
        mainScreen.style.display = '';
        return;
      }
    } else {
      localStorage.setItem('volunteer_pin', pin);
      pinScreen.style.display = 'none';
      mainScreen.style.display = '';
      return;
    }

    pinError.style.display = '';
    pinInput.value = '';
    pinInput.focus();
  }

  // === Image Handling ===
  async function handleImageSelect(e) {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;

    const slots = MAX_PHOTOS - currentPhotos.length;
    if (slots <= 0) {
      alert(t('maxPhotosReached').replace('{max}', MAX_PHOTOS));
      e.target.value = '';
      return;
    }

    const toAdd = files.slice(0, slots);
    for (const file of toAdd) {
      try {
        const b64 = await compressImage(file);
        if (currentPhotos.length < MAX_PHOTOS) currentPhotos.push(b64);
      } catch (err) {
        console.error('Compress failed:', err);
      }
    }

    e.target.value = '';
    renderPhotoStrip();
    // Reveal action buttons; wait for user to tap "Analyze" so they can add more photos first
    skipAiBtn.style.display = '';
    analyzeBtn.style.display = '';
  }

  function renderPhotoStrip() {
    photoStrip.innerHTML = '';
    if (currentPhotos.length === 0) {
      photoStrip.style.display = 'none';
      photoCountHint.style.display = 'none';
      analyzeBtn.style.display = 'none';
      return;
    }

    photoStrip.style.display = '';
    photoCountHint.style.display = '';

    currentPhotos.forEach((b64, idx) => {
      const thumb = document.createElement('div');
      thumb.className = 'photo-thumb';
      if (idx === 0) thumb.classList.add('photo-thumb-primary');
      thumb.innerHTML = `
        <img src="data:image/jpeg;base64,${b64}" alt="photo ${idx + 1}">
        <button class="photo-thumb-remove" type="button" aria-label="Remove photo">&times;</button>
        ${idx === 0 ? `<span class="photo-thumb-badge">1</span>` : ''}
      `;
      thumb.querySelector('.photo-thumb-remove').addEventListener('click', (e) => {
        e.stopPropagation();
        currentPhotos.splice(idx, 1);
        renderPhotoStrip();
        if (currentPhotos.length === 0) {
          skipAiBtn.style.display = 'none';
          analyzeBtn.style.display = 'none';
        }
      });
      photoStrip.appendChild(thumb);
    });

    // "Add more" tile (only if room left)
    if (currentPhotos.length < MAX_PHOTOS) {
      const addTile = document.createElement('label');
      addTile.className = 'photo-thumb photo-thumb-add';
      addTile.setAttribute('for', 'cameraInput');
      addTile.innerHTML = `<span class="photo-thumb-plus">+</span>`;
      photoStrip.appendChild(addTile);
    }

    analyzeBtn.style.display = '';
  }

  async function analyzeImage() {
    hideAllSections();
    analysisLoading.style.display = '';

    try {
      const result = await apiFetch('/api/analyze', {
        method: 'POST',
        body: JSON.stringify({
          images: currentPhotos,
          language: getCurrentLang()
        })
      });

      analysisLoading.style.display = 'none';

      if (!result.singleItem && result.items) {
        showMultiSelect(result.items);
      } else if (result.needsInput) {
        showMaterialsSelection(result);
      } else {
        showPriceCard(result);
      }
    } catch (err) {
      console.error('Analysis failed:', err);
      analysisLoading.style.display = 'none';
      alert(err.message || t('analysisFailed'));
    }
  }

  function showMultiSelect(items) {
    multiSelect.style.display = '';
    multiList.innerHTML = '';

    items.forEach(itemName => {
      const btn = document.createElement('button');
      btn.className = 'multi-item';
      btn.textContent = itemName;
      btn.addEventListener('click', () => {
        multiSelect.style.display = 'none';
        analyzeSpecificItem(itemName);
      });
      multiList.appendChild(btn);
    });

    // Add "Other / Not listed" option
    const otherBtn = document.createElement('button');
    otherBtn.className = 'multi-item multi-item-other';
    otherBtn.textContent = t('otherNotListed');
    otherBtn.addEventListener('click', () => {
      multiSelect.style.display = 'none';
      analyzeSpecificItem('the main item in the center of the photo');
    });
    multiList.appendChild(otherBtn);
  }

  async function analyzeSpecificItem(itemName) {
    analysisLoading.style.display = '';

    try {
      const result = await apiFetch('/api/analyze', {
        method: 'POST',
        body: JSON.stringify({
          images: currentPhotos,
          language: getCurrentLang(),
          specificItem: itemName
        })
      });

      analysisLoading.style.display = 'none';

      if (result.needsInput) {
        showMaterialsSelection(result);
      } else {
        showPriceCard(result);
      }
    } catch (err) {
      console.error('Analysis failed:', err);
      analysisLoading.style.display = 'none';
      alert(err.message || t('analysisFailed'));
    }
  }

  // === Materials Selection Flow ===
  function showMaterialsSelection(data) {
    pendingMaterialsData = data;
    materialsSection.style.display = '';

    document.getElementById('materialsItemName').textContent = data.itemName || t('unknownItem');
    document.getElementById('materialsReasoning').textContent = data.reasoning || '';

    // Show "take another photo" hint if AI wants a better angle
    const photoHintEl = document.getElementById('photoHintSection');
    if (data.needsMorePhotos && data.photoHint) {
      photoHintEl.style.display = '';
      document.getElementById('photoHintText').textContent = data.photoHint;
    } else {
      photoHintEl.style.display = 'none';
    }

    // Build materials buttons
    const allMaterials = [
      'wood', 'metal', 'plastic', 'fabric', 'leather',
      'glass', 'ceramic', 'rubber', 'paper', 'stone', 'other'
    ];
    const detected = data.detectedMaterials || [];

    materialsGrid.innerHTML = '';
    allMaterials.forEach(mat => {
      const btn = document.createElement('button');
      btn.className = 'material-btn' + (detected.includes(mat) ? ' active' : '');
      btn.dataset.material = mat;
      btn.textContent = t('material_' + mat);
      btn.addEventListener('click', () => btn.classList.toggle('active'));
      materialsGrid.appendChild(btn);
    });

    // Pre-select condition if AI guessed one
    if (data.condition) {
      conditionOptions.querySelectorAll('.filter-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.condition === data.condition);
      });
    }
  }

  async function submitMaterials() {
    const selectedMaterials = Array.from(materialsGrid.querySelectorAll('.material-btn.active'))
      .map(btn => btn.dataset.material);

    if (selectedMaterials.length === 0) {
      alert(t('selectAtLeastOneMaterial'));
      return;
    }

    const selectedCondition = conditionOptions.querySelector('.filter-btn.active');
    const condition = selectedCondition ? selectedCondition.dataset.condition : 'fair';

    materialsTried = true;
    materialsSection.style.display = 'none';
    analysisLoading.style.display = '';

    try {
      const result = await apiFetch('/api/analyze', {
        method: 'POST',
        body: JSON.stringify({
          images: currentPhotos,
          language: getCurrentLang(),
          materials: selectedMaterials,
          userCondition: condition
        })
      });

      analysisLoading.style.display = 'none';
      showPriceCard(result);
    } catch (err) {
      console.error('Materials pricing failed:', err);
      analysisLoading.style.display = 'none';
      alert(err.message || t('pricingFailed'));
    }
  }

  // === Price Card ===
  function showPriceCard(data) {
    // If prices are missing/zero, go to materials first, then manual
    if (!data.recommendedShopPrice && !data.estimatedMarketPrice) {
      if (!materialsTried) {
        showMaterialsSelection(data);
      } else {
        showManualPricing(data);
      }
      return;
    }

    currentAnalysis = data;
    priceCard.style.display = '';

    document.getElementById('resultName').textContent = data.itemName || '—';
    document.getElementById('resultCategory').textContent = t(data.category) || data.category || '—';

    // Handle missing condition gracefully
    const condEl = document.getElementById('resultCondition');
    if (data.condition) {
      condEl.textContent = formatCondition(data.condition);
      condEl.style.display = '';
    } else {
      condEl.style.display = 'none';
    }

    const brandEl = document.getElementById('resultBrand');
    if (data.brand) {
      brandEl.textContent = data.brand;
      brandEl.style.display = '';
    } else {
      brandEl.style.display = 'none';
    }

    // Handle missing confidence gracefully
    const confEl = document.getElementById('resultConfidence');
    if (data.confidence) {
      confEl.textContent = formatConfidence(data.confidence);
      confEl.style.display = '';
    } else {
      confEl.style.display = 'none';
    }

    document.getElementById('resultMarketPrice').textContent = formatPrice(data.estimatedMarketPrice);
    document.getElementById('resultShopPrice').textContent = formatPrice(data.recommendedShopPrice);
    document.getElementById('resultReasoning').textContent = data.reasoning || '';
    document.getElementById('finalPriceInput').value = data.recommendedShopPrice || '';
  }

  // === Manual Pricing (last resort) ===
  function showManualPricing(data) {
    hideAllSections();
    skipAiBtn.style.display = 'none';
    manualPriceCard.style.display = '';

    // Pre-fill from AI data if available
    document.getElementById('manualName').value = (data && data.itemName) || '';
    document.getElementById('manualPrice').value = '';

    if (data && data.category) {
      document.getElementById('manualCategory').value = data.category;
    } else {
      document.getElementById('manualCategory').value = 'other';
    }

    if (data && data.condition) {
      manualConditionOptions.querySelectorAll('.filter-btn').forEach(b => {
        b.classList.toggle('active', b.dataset.condition === data.condition);
      });
    }
  }

  async function saveManualItem() {
    const name = document.getElementById('manualName').value.trim();
    const price = parseFloat(document.getElementById('manualPrice').value);
    const category = document.getElementById('manualCategory').value;
    const condBtn = manualConditionOptions.querySelector('.filter-btn.active');
    const condition = condBtn ? condBtn.dataset.condition : 'fair';

    if (!name) { alert(t('enterDescription')); return; }
    if (!price || price <= 0) { alert(t('enterPrice')); return; }
    if (currentPhotos.length === 0) { alert(t('noPhoto')); return; }

    manualSaveBtn.disabled = true;
    manualSaveBtn.textContent = '...';

    try {
      await apiFetch('/api/item', {
        method: 'POST',
        body: JSON.stringify({
          photos: currentPhotos,
          description: name,
          category: category,
          brand: null,
          condition: condition,
          ai_suggested_price: null,
          final_price: price,
          language: getCurrentLang(),
          ai_reasoning: t('manualPricingReasoning'),
          ai_confidence: null
        })
      });

      manualPriceCard.style.display = 'none';
      saveSuccess.style.display = '';
      loadTodayItems();
    } catch (err) {
      console.error('Save failed:', err);
      alert(err.message || t('saveFailed'));
    } finally {
      manualSaveBtn.disabled = false;
      manualSaveBtn.textContent = t('saveItem');
    }
  }

  // === Save Item ===
  async function saveItem() {
    if (!currentAnalysis || currentPhotos.length === 0) return;

    saveItemBtn.disabled = true;
    saveItemBtn.textContent = '...';

    const finalPrice = parseFloat(document.getElementById('finalPriceInput').value) || currentAnalysis.recommendedShopPrice;

    try {
      await apiFetch('/api/item', {
        method: 'POST',
        body: JSON.stringify({
          photos: currentPhotos,
          description: currentAnalysis.itemName,
          category: currentAnalysis.category,
          brand: currentAnalysis.brand || null,
          condition: currentAnalysis.condition,
          ai_suggested_price: currentAnalysis.recommendedShopPrice,
          final_price: finalPrice,
          language: getCurrentLang(),
          ai_reasoning: currentAnalysis.reasoning,
          ai_confidence: currentAnalysis.confidence
        })
      });

      priceCard.style.display = 'none';
      saveSuccess.style.display = '';
      loadTodayItems();
    } catch (err) {
      console.error('Save failed:', err);
      alert(err.message || t('saveFailed'));
    } finally {
      saveItemBtn.disabled = false;
      saveItemBtn.textContent = t('saveItem');
    }
  }

  // === Reset ===
  function resetFlow() {
    hideAllSections();
    skipAiBtn.style.display = 'none';
    analyzeBtn.style.display = 'none';
    currentPhotos = [];
    currentAnalysis = null;
    pendingMaterialsData = null;
    materialsTried = false;
    cameraInput.value = '';
    galleryInput.value = '';
    renderPhotoStrip();
  }

  function hideAllSections() {
    analysisLoading.style.display = 'none';
    multiSelect.style.display = 'none';
    materialsSection.style.display = 'none';
    priceCard.style.display = 'none';
    manualPriceCard.style.display = 'none';
    saveSuccess.style.display = 'none';
  }

  // === Today's Items ===
  async function loadTodayItems() {
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const data = await apiFetch('/api/items?status=available&limit=50&offset=0');

      if (!data.items || data.items.length === 0) {
        todayList.innerHTML = `<p class="muted">${t('noTodayItems')}</p>`;
        return;
      }

      const todayItems = data.items.filter(item => {
        return new Date(item.created_at) >= today;
      });

      if (todayItems.length === 0) {
        todayList.innerHTML = `<p class="muted">${t('noTodayItems')}</p>`;
        return;
      }

      // Translate item descriptions to the current language
      const translatedItems = await translateItems(todayItems, getCurrentLang());

      todayList.innerHTML = '';
      translatedItems.forEach(item => {
        todayList.appendChild(createTodayItem(item));
      });
    } catch (err) {
      console.log('Could not load today items:', err);
    }
  }

  function createTodayItem(item) {
    const el = document.createElement('div');
    el.className = 'today-item';

    const price = item.final_price || item.ai_suggested_price;
    const photos = (Array.isArray(item.photo_urls) && item.photo_urls.length > 0)
      ? item.photo_urls
      : (item.photo_url ? [item.photo_url] : []);
    const primaryPhoto = photos[0] || '';
    const photoCount = photos.length > 1
      ? `<span class="today-item-photo-count">&#x1F4F7; ${photos.length}</span>`
      : '';

    el.innerHTML = `
      <div class="today-item-img-wrap">
        <img class="today-item-img" src="${escapeHtml(primaryPhoto)}" alt="" loading="lazy">
        ${photoCount}
      </div>
      <div class="today-item-info">
        <div class="today-item-name">${escapeHtml(item.description)}</div>
        <div class="today-item-footer">
          <div class="today-item-price">${formatPrice(price)}</div>
          ${priceBadgeHtml(price)}
        </div>
      </div>
      <div class="today-item-actions">
        <button class="btn btn-sm btn-primary mark-sold-btn" data-id="${item.id}">${t('markSold')}</button>
      </div>
    `;

    el.querySelector('.mark-sold-btn').addEventListener('click', (e) => {
      const btn = e.target;
      const listedPrice = item.final_price || item.ai_suggested_price;
      showSoldPricePrompt(listedPrice, async (soldPrice) => {
        btn.disabled = true;
        try {
          await apiFetch('/api/item', {
            method: 'PATCH',
            body: JSON.stringify({ id: item.id, status: 'sold', sold_price: soldPrice })
          });
          el.remove();
        } catch (err) {
          console.error('Mark sold failed:', err);
          btn.disabled = false;
        }
      });
    });

    return el;
  }

  // === Sold Price Prompt ===
  function showSoldPricePrompt(listedPrice, onConfirm) {
    const modal = document.getElementById('volunteerSoldPriceModal');
    const input = document.getElementById('volunteerSoldPriceInput');
    const confirmBtn = document.getElementById('volunteerSoldPriceConfirmBtn');
    const cancelBtn = document.getElementById('volunteerSoldPriceCancelBtn');

    input.value = listedPrice || '';
    input.placeholder = t('soldPricePlaceholder');
    modal.style.display = 'flex';
    setTimeout(() => { input.focus(); input.select(); }, 100);

    function cleanup() {
      modal.style.display = 'none';
      confirmBtn.removeEventListener('click', handleConfirm);
      cancelBtn.removeEventListener('click', handleCancel);
    }

    function handleConfirm() {
      const soldPrice = parseFloat(input.value) || null;
      cleanup();
      onConfirm(soldPrice);
    }

    function handleCancel() {
      cleanup();
    }

    confirmBtn.addEventListener('click', handleConfirm);
    cancelBtn.addEventListener('click', handleCancel);
  }

  function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }

  // === Category Management ===
  async function loadCategories() {
    try {
      const data = await apiFetch('/api/categories');
      categoriesCache = data.categories || [];
      populateCategoryDropdown();
      renderCategoryList();
    } catch (err) {
      console.log('Could not load categories:', err);
    }
  }

  function getCategoryDisplayName(cat) {
    // For subcategories: "Group > Subcategory"
    // For simple categories: use t() for default categories, stored name for custom
    if (cat.subLabel) {
      return t(cat.groupLabel) + ' > ' + t(cat.subLabel);
    }
    const translated = t(cat.id);
    if (translated !== cat.id) {
      return translated;
    }
    const lang = getCurrentLang();
    if (typeof cat.name === 'object') {
      return cat.name[lang] || cat.name.es || cat.name.en || cat.id;
    }
    return cat.name || cat.id;
  }

  function populateCategoryDropdown() {
    const select = document.getElementById('manualCategory');
    select.innerHTML = '';

    // Group categories by their group for visual grouping in dropdown
    const groups = {};
    categoriesCache.forEach(cat => {
      const groupKey = cat.group || cat.id;
      if (!groups[groupKey]) groups[groupKey] = [];
      groups[groupKey].push(cat);
    });

    Object.keys(groups).forEach(groupKey => {
      const items = groups[groupKey];
      if (items.length === 1 && !items[0].subLabel) {
        // Simple category, no optgroup needed
        const opt = document.createElement('option');
        opt.value = items[0].id;
        opt.textContent = getCategoryDisplayName(items[0]);
        select.appendChild(opt);
      } else {
        // Group with subcategories
        const groupLabel = items[0].groupLabel || getCategoryDisplayName(items[0]);
        const optgroup = document.createElement('optgroup');
        optgroup.label = groupLabel;
        items.forEach(cat => {
          const opt = document.createElement('option');
          opt.value = cat.id;
          opt.textContent = cat.subLabel || getCategoryDisplayName(cat);
          optgroup.appendChild(opt);
        });
        select.appendChild(optgroup);
      }
    });

    if (categoriesCache.some(c => c.id === 'other')) {
      select.value = 'other';
    }
  }

  function renderCategoryList() {
    const list = document.getElementById('categoryList');
    list.innerHTML = '';

    categoriesCache.forEach(cat => {
      const row = document.createElement('div');
      row.className = 'category-row';

      const nameSpan = document.createElement('span');
      nameSpan.className = 'category-row-name';
      nameSpan.textContent = getCategoryDisplayName(cat);

      const actions = document.createElement('div');
      actions.className = 'category-row-actions';

      const deleteBtn = document.createElement('button');
      deleteBtn.className = 'btn btn-sm btn-danger';
      deleteBtn.textContent = t('delete');
      deleteBtn.addEventListener('click', () => openDeleteModal(cat));

      actions.appendChild(deleteBtn);

      row.appendChild(nameSpan);
      row.appendChild(actions);
      list.appendChild(row);
    });
  }

  function setupCategoryManagement() {
    document.getElementById('addCategoryBtn').addEventListener('click', addCategory);

    document.getElementById('catDeleteCancelBtn').addEventListener('click', () => {
      document.getElementById('categoryDeleteModal').style.display = 'none';
      deletingCategoryId = null;
    });
    document.getElementById('catDeleteConfirmBtn').addEventListener('click', confirmDelete);

    // Collapsible category toggle
    const toggle = document.getElementById('categoryToggle');
    const collapsible = document.getElementById('categoryCollapsible');
    const icon = document.getElementById('categoryToggleIcon');
    if (toggle && collapsible) {
      toggle.addEventListener('click', () => {
        collapsible.classList.toggle('open');
        icon.classList.toggle('open');
      });
    }
  }

  async function addCategory() {
    const groupInput = document.getElementById('newCategoryGroup');
    const nameInput = document.getElementById('newCategoryName');
    const category = groupInput.value.trim();
    const subcategory = nameInput.value.trim();

    if (!category) { alert(t('enterCategoryName')); return; }

    const lang = getCurrentLang();
    const nameObj = subcategory
      ? { [lang]: category + ' > ' + subcategory }
      : { [lang]: category };

    try {
      const data = await apiFetch('/api/categories', {
        method: 'POST',
        body: JSON.stringify({ category, subcategory: subcategory || null, name: nameObj })
      });
      categoriesCache = data.categories;
      populateCategoryDropdown();
      renderCategoryList();
      groupInput.value = '';
      nameInput.value = '';
    } catch (err) {
      alert(err.message || t('categoryExists'));
    }
  }

  function openDeleteModal(cat) {
    deletingCategoryId = cat.id;
    document.getElementById('categoryDeleteModal').style.display = 'flex';
  }

  async function confirmDelete() {
    if (!deletingCategoryId) return;
    try {
      const data = await apiFetch('/api/categories', {
        method: 'DELETE',
        body: JSON.stringify({ id: deletingCategoryId })
      });
      categoriesCache = data.categories;
      populateCategoryDropdown();
      renderCategoryList();
      document.getElementById('categoryDeleteModal').style.display = 'none';
      deletingCategoryId = null;
    } catch (err) {
      alert(err.message || t('deleteFailed'));
    }
  }

  // === Badge Management ===
  function setupBadgeManagement() {
    const toggle = document.getElementById('badgeToggle');
    const collapsible = document.getElementById('badgeCollapsible');
    const icon = document.getElementById('badgeToggleIcon');
    if (toggle && collapsible) {
      toggle.addEventListener('click', () => {
        collapsible.classList.toggle('open');
        icon.classList.toggle('open');
      });
    }

    renderBadgeRows();

    const saveBtn = document.getElementById('saveBadgesBtn');
    if (saveBtn) {
      saveBtn.addEventListener('click', saveBadges);
    }
  }

  function renderBadgeRows() {
    const container = document.getElementById('badgeRowsList');
    if (!container) return;
    container.innerHTML = '';

    priceBadgesConfig.forEach((badge, i) => {
      const row = document.createElement('div');
      row.className = 'badge-row';
      const maxVal = badge.max !== null ? badge.max : '';
      const maxPlaceholder = badge.max === null ? t('badgeNoLimit') : '';
      row.innerHTML = `
        <span class="badge-row-emoji">${badge.emoji}</span>
        <span class="badge-row-label">${t('badgeFrom')}</span>
        <input type="number" class="manual-input badge-input" value="${badge.min}" min="0" step="0.5" data-index="${i}" data-field="min">
        <span class="badge-row-label">${t('badgeTo')}</span>
        <input type="number" class="manual-input badge-input" value="${maxVal}" min="0" step="0.5" placeholder="${maxPlaceholder}" data-index="${i}" data-field="max">
      `;
      container.appendChild(row);
    });
  }

  async function saveBadges() {
    const inputs = document.querySelectorAll('#badgeRowsList .badge-input');
    const updated = [...priceBadgesConfig];

    inputs.forEach(input => {
      const idx = parseInt(input.dataset.index);
      const field = input.dataset.field;
      if (field === 'min') {
        updated[idx] = { ...updated[idx], min: parseFloat(input.value) || 0 };
      } else if (field === 'max') {
        const val = input.value.trim();
        updated[idx] = { ...updated[idx], max: val === '' ? null : (parseFloat(val) || 0) };
      }
    });

    const saveBtn = document.getElementById('saveBadgesBtn');
    try {
      if (saveBtn) saveBtn.disabled = true;
      await apiFetch('/api/badges', {
        method: 'PUT',
        body: JSON.stringify({ badges: updated })
      });
      priceBadgesConfig = updated;
      loadTodayItems();
      const msg = document.getElementById('badgeSavedMsg');
      if (msg) {
        msg.style.display = '';
        setTimeout(() => { msg.style.display = 'none'; }, 2000);
      }
    } catch (err) {
      alert(err.message || t('actionFailed'));
    } finally {
      if (saveBtn) saveBtn.disabled = false;
    }
  }

  // === Agenda (Workshops / Events) Management ===
  let agendaKind = 'workshop';
  let agendaEditingId = null;
  let agendaPendingPhotos = []; // { base64, previewUrl }
  let agendaExistingUrls = [];  // urls kept when editing
  let agendaList = [];

  document.addEventListener('DOMContentLoaded', () => {
    setupAgendaManagement();
  });

  function setupAgendaManagement() {
    const toggle = document.getElementById('agendaToggle');
    const collapsible = document.getElementById('agendaCollapsible');
    const icon = document.getElementById('agendaToggleIcon');
    if (!toggle || !collapsible) return;

    toggle.addEventListener('click', () => {
      collapsible.classList.toggle('open');
      icon.classList.toggle('open');
      if (collapsible.classList.contains('open') && agendaList.length === 0) {
        loadAgendaList();
      }
    });

    const kindToggle = document.getElementById('agendaKindToggle');
    kindToggle.addEventListener('click', (e) => {
      const btn = e.target.closest('.filter-btn');
      if (!btn) return;
      kindToggle.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      agendaKind = btn.dataset.kind;
      loadAgendaList();
    });

    document.getElementById('agendaPhotosInput').addEventListener('change', handleAgendaPhotoSelect);
    document.getElementById('agendaSaveBtn').addEventListener('click', saveAgenda);
    document.getElementById('agendaCancelBtn').addEventListener('click', resetAgendaForm);
    const comingSoonCb = document.getElementById('agendaComingSoon');
    if (comingSoonCb) {
      comingSoonCb.addEventListener('change', applyComingSoonState);
    }

    // Deep link from public page's "edit" button
    if (window.location.hash === '#agenda') {
      collapsible.classList.add('open');
      icon.classList.add('open');
      const pendingEditId = localStorage.getItem('agenda_edit_id');
      if (pendingEditId) {
        localStorage.removeItem('agenda_edit_id');
        // Load list first, then open edit
        loadAgendaList().then(() => {
          const ev = agendaList.find(e => e.id === pendingEditId);
          if (ev) {
            agendaKind = ev.kind;
            kindToggle.querySelectorAll('.filter-btn').forEach(b => {
              b.classList.toggle('active', b.dataset.kind === agendaKind);
            });
            editAgendaEvent(ev);
          }
        });
        return;
      }
    }

    // Only load if section is open
    if (collapsible.classList.contains('open')) loadAgendaList();
  }

  async function handleAgendaPhotoSelect(e) {
    const files = Array.from(e.target.files || []);
    for (const file of files) {
      const previewUrl = URL.createObjectURL(file);
      const base64 = await compressImage(file, 1200, 0.8);
      agendaPendingPhotos.push({ base64, previewUrl });
    }
    e.target.value = '';
    renderAgendaPhotoPreviews();
  }

  function renderAgendaPhotoPreviews() {
    const container = document.getElementById('agendaPhotosPreview');
    container.innerHTML = '';

    agendaExistingUrls.forEach((url, idx) => {
      const tile = document.createElement('div');
      tile.className = 'agenda-photo-tile';
      tile.innerHTML = `
        <img src="${escapeHtml(url)}" alt="">
        <button class="agenda-photo-remove" title="${t('delete')}">&times;</button>
      `;
      tile.querySelector('.agenda-photo-remove').addEventListener('click', () => {
        agendaExistingUrls.splice(idx, 1);
        renderAgendaPhotoPreviews();
      });
      container.appendChild(tile);
    });

    agendaPendingPhotos.forEach((p, idx) => {
      const tile = document.createElement('div');
      tile.className = 'agenda-photo-tile agenda-photo-tile-new';
      tile.innerHTML = `
        <img src="${escapeHtml(p.previewUrl)}" alt="">
        <button class="agenda-photo-remove" title="${t('delete')}">&times;</button>
      `;
      tile.querySelector('.agenda-photo-remove').addEventListener('click', () => {
        agendaPendingPhotos.splice(idx, 1);
        renderAgendaPhotoPreviews();
      });
      container.appendChild(tile);
    });
  }

  function resetAgendaForm() {
    agendaEditingId = null;
    agendaPendingPhotos = [];
    agendaExistingUrls = [];
    document.getElementById('agendaTitle').value = '';
    document.getElementById('agendaStartsAt').value = '';
    document.getElementById('agendaEndsAt').value = '';
    document.getElementById('agendaLocation').value = '';
    document.getElementById('agendaDescription').value = '';
    document.getElementById('agendaPrice').value = '';
    document.getElementById('agendaCapacity').value = '';
    document.getElementById('agendaOrganizer').value = '';
    document.getElementById('agendaContact').value = '';
    document.getElementById('agendaRequirements').value = '';
    document.getElementById('agendaVideoUrl').value = '';
    const cs = document.getElementById('agendaComingSoon');
    if (cs) cs.checked = false;
    applyComingSoonState();
    renderAgendaPhotoPreviews();
    document.getElementById('agendaSaveBtn').textContent = t('saveEvent');
  }

  // Sentinel used in the DB to mark entries without a confirmed date.
  // Any starts_at whose UTC year is 9999 is treated as "coming soon".
  const COMING_SOON_SENTINEL_ISO = '9999-12-31T00:00:00.000Z';
  function isComingSoonIso(iso) {
    if (!iso) return false;
    const d = new Date(iso);
    return !isNaN(d) && d.getUTCFullYear() === 9999;
  }

  function applyComingSoonState() {
    const cb = document.getElementById('agendaComingSoon');
    const startsInput = document.getElementById('agendaStartsAt');
    const endsInput = document.getElementById('agendaEndsAt');
    if (!cb) return;
    const checked = cb.checked;
    if (checked) {
      startsInput.value = '';
      endsInput.value = '';
    }
    startsInput.disabled = checked;
    endsInput.disabled = checked;
  }

  function toLocalDatetimeValue(iso) {
    if (!iso) return '';
    const d = new Date(iso);
    const pad = n => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function editAgendaEvent(ev) {
    agendaEditingId = ev.id;
    agendaKind = ev.kind;
    agendaPendingPhotos = [];
    agendaExistingUrls = Array.isArray(ev.photo_urls) ? [...ev.photo_urls] : [];
    document.getElementById('agendaTitle').value = ev.title || '';
    const comingSoon = isComingSoonIso(ev.starts_at);
    const csCb = document.getElementById('agendaComingSoon');
    if (csCb) csCb.checked = comingSoon;
    document.getElementById('agendaStartsAt').value = comingSoon ? '' : toLocalDatetimeValue(ev.starts_at);
    document.getElementById('agendaEndsAt').value = comingSoon ? '' : toLocalDatetimeValue(ev.ends_at);
    applyComingSoonState();
    document.getElementById('agendaLocation').value = ev.location || '';
    document.getElementById('agendaDescription').value = ev.description || '';
    document.getElementById('agendaPrice').value = ev.price_eur == null ? '' : ev.price_eur;
    document.getElementById('agendaCapacity').value = ev.capacity || '';
    document.getElementById('agendaOrganizer').value = ev.organizer || '';
    document.getElementById('agendaContact').value = ev.contact || '';
    document.getElementById('agendaRequirements').value = ev.requirements || '';
    document.getElementById('agendaVideoUrl').value = ev.video_url || '';
    renderAgendaPhotoPreviews();
    document.getElementById('agendaSaveBtn').textContent = t('updateEvent');
    document.getElementById('agendaForm').scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function saveAgenda() {
    const title = document.getElementById('agendaTitle').value.trim();
    const startsAt = document.getElementById('agendaStartsAt').value;
    const comingSoon = !!(document.getElementById('agendaComingSoon') && document.getElementById('agendaComingSoon').checked);
    if (!title) { alert(t('enterTitle')); return; }
    if (!comingSoon && !startsAt) { alert(t('enterStartsAt')); return; }

    const endsAtRaw = document.getElementById('agendaEndsAt').value;
    const payload = {
      kind: agendaKind,
      title,
      starts_at: comingSoon ? COMING_SOON_SENTINEL_ISO : new Date(startsAt).toISOString(),
      ends_at: comingSoon ? null : (endsAtRaw ? new Date(endsAtRaw).toISOString() : null),
      location: document.getElementById('agendaLocation').value.trim() || null,
      description: document.getElementById('agendaDescription').value.trim() || null,
      price_eur: document.getElementById('agendaPrice').value.trim() || null,
      capacity: document.getElementById('agendaCapacity').value.trim() || null,
      organizer: document.getElementById('agendaOrganizer').value.trim() || null,
      contact: document.getElementById('agendaContact').value.trim() || null,
      requirements: document.getElementById('agendaRequirements').value.trim() || null,
      video_url: document.getElementById('agendaVideoUrl').value.trim() || null,
      language: getCurrentLang(),
      photos: agendaPendingPhotos.map(p => p.base64)
    };

    const saveBtn = document.getElementById('agendaSaveBtn');
    saveBtn.disabled = true;
    const origLabel = saveBtn.textContent;
    saveBtn.textContent = '...';

    try {
      if (agendaEditingId) {
        payload.id = agendaEditingId;
        payload.photo_urls = agendaExistingUrls;
        await apiFetch('/api/event', { method: 'PATCH', body: JSON.stringify(payload) });
      } else {
        await apiFetch('/api/event', { method: 'POST', body: JSON.stringify(payload) });
      }
      resetAgendaForm();
      await loadAgendaList();
    } catch (err) {
      console.error('Save agenda failed:', err);
      alert(err.message || t('saveFailed'));
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = origLabel;
    }
  }

  async function loadAgendaList() {
    const container = document.getElementById('agendaList');
    if (!container) return;
    container.innerHTML = `<p class="muted">${t('loading')}</p>`;
    try {
      const data = await apiFetch('/api/events?kind=' + agendaKind + '&when=all&limit=50');
      agendaList = data.events || [];
      await renderAgendaList();
    } catch (err) {
      console.error('Load agenda failed:', err);
      container.innerHTML = `<p class="muted">${t('actionFailed')}</p>`;
    }
  }

  function formatAgendaDate(iso) {
    if (!iso) return '';
    if (isComingSoonIso(iso)) return t('comingSoon');
    try {
      const d = new Date(iso);
      const lang = getCurrentLang();
      return d.toLocaleDateString(lang, { day: '2-digit', month: 'short', year: 'numeric' })
        + ' · ' + d.toLocaleTimeString(lang, { hour: '2-digit', minute: '2-digit' });
    } catch (e) { return iso; }
  }

  async function renderAgendaList() {
    const container = document.getElementById('agendaList');
    container.innerHTML = '';
    if (agendaList.length === 0) {
      container.innerHTML = `<p class="muted">${t('noEvents')}</p>`;
      return;
    }
    // Translate for display only. Edit handler still uses the original
    // event object so saving never overwrites the Spanish source with
    // a translated version.
    let displayList = agendaList;
    if (typeof translateEvents === 'function') {
      try { displayList = await translateEvents(agendaList, getCurrentLang()); }
      catch (e) { displayList = agendaList; }
    }
    displayList.forEach(displayEv => {
      const originalEv = agendaList.find(e => e.id === displayEv.id) || displayEv;
      const row = document.createElement('div');
      const isPast = !isComingSoonIso(displayEv.starts_at)
        && new Date(displayEv.ends_at || displayEv.starts_at).getTime() < Date.now();
      row.className = 'agenda-row' + (isPast ? ' agenda-row-past' : '');
      const cover = (Array.isArray(displayEv.photo_urls) && displayEv.photo_urls[0]) || '';
      row.innerHTML = `
        <div class="agenda-row-thumb">
          ${cover ? `<img src="${escapeHtml(cover)}" alt="">` : `<div class="agenda-row-thumb-placeholder">${displayEv.kind === 'workshop' ? '🎨' : '📅'}</div>`}
        </div>
        <div class="agenda-row-info">
          <div class="agenda-row-title">${escapeHtml(displayEv.title)}</div>
          <div class="agenda-row-date">${escapeHtml(formatAgendaDate(displayEv.starts_at))}</div>
        </div>
        <div class="agenda-row-actions">
          <button class="btn btn-sm btn-secondary agenda-edit-btn">${t('edit')}</button>
          <button class="btn btn-sm btn-danger agenda-del-btn">${t('delete')}</button>
        </div>
      `;
      row.querySelector('.agenda-edit-btn').addEventListener('click', () => editAgendaEvent(originalEv));
      row.querySelector('.agenda-del-btn').addEventListener('click', async () => {
        if (!confirm(t('confirmDeleteEvent'))) return;
        try {
          await apiFetch('/api/event', { method: 'DELETE', body: JSON.stringify({ id: originalEv.id }) });
          loadAgendaList();
        } catch (err) {
          alert(err.message || t('deleteFailed'));
        }
      });
      container.appendChild(row);
    });
  }
})();
