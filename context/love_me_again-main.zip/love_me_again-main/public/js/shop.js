// Shop page logic
(function() {
  let currentCategory = 'all';
  let currentTab = 'available';
  let availableOffset = 0;
  let soldOffset = 0;
  const limit = 20;
  let availableTotal = 0;
  let soldTotal = 0;
  let isVolunteer = !!localStorage.getItem('volunteer_pin');
  let deleteItemId = null;
  let categoriesData = [];

  const loading = document.getElementById('loading');
  const availableSection = document.getElementById('availableSection');
  const availableGrid = document.getElementById('availableGrid');
  const availableLoadMore = document.getElementById('availableLoadMore');
  const availableLoadMoreBtn = document.getElementById('availableLoadMoreBtn');
  const availableEmpty = document.getElementById('availableEmpty');
  const soldSection = document.getElementById('soldSection');
  const soldGrid = document.getElementById('soldGrid');
  const soldLoadMore = document.getElementById('soldLoadMore');
  const soldLoadMoreBtn = document.getElementById('soldLoadMoreBtn');
  const soldEmpty = document.getElementById('soldEmpty');
  const modal = document.getElementById('itemModal');
  const modalClose = document.getElementById('modalClose');
  const modalActions = document.getElementById('modalActions');
  const modalDeleteBtn = document.getElementById('modalDeleteBtn');
  const modalReserveBtn = document.getElementById('modalReserveBtn');
  const modalSoldBtn = document.getElementById('modalSoldBtn');
  const deleteModal = document.getElementById('deleteModal');
  const deleteCancelBtn = document.getElementById('deleteCancelBtn');
  const deleteConfirmBtn = document.getElementById('deleteConfirmBtn');
  const soldPriceModal = document.getElementById('soldPriceModal');
  const soldPriceInput = document.getElementById('soldPriceInput');
  const soldPriceCancelBtn = document.getElementById('soldPriceCancelBtn');
  const soldPriceConfirmBtn = document.getElementById('soldPriceConfirmBtn');
  const sectionTabs = document.getElementById('sectionTabs');

  let currentModalItem = null;
  let modalGalleryPhotos = [];
  let modalGalleryIndex = 0;
  let photoSwipeInstance = null;

  function loadPhotoSwipe() {
    import('https://cdn.jsdelivr.net/npm/photoswipe@5.4.4/dist/photoswipe.esm.js')
      .then(mod => { window.__PhotoSwipe = mod.default || mod; })
      .catch(err => console.warn('PhotoSwipe load failed:', err));
  }

  async function openPhotoSwipe(photos, startIndex) {
    const PhotoSwipe = window.__PhotoSwipe;
    if (!PhotoSwipe) {
      window.open(photos[startIndex], '_blank');
      return;
    }
    if (photoSwipeInstance) {
      try { photoSwipeInstance.destroy(); } catch (e) {}
      photoSwipeInstance = null;
    }
    const dataSource = await Promise.all(photos.map(url => new Promise(resolve => {
      const img = new Image();
      img.onload = () => resolve({ src: url, width: img.naturalWidth || 1600, height: img.naturalHeight || 1600 });
      img.onerror = () => resolve({ src: url, width: 1600, height: 1600 });
      img.src = url;
    })));
    photoSwipeInstance = new PhotoSwipe({
      dataSource,
      index: startIndex,
      showHideAnimationType: 'zoom',
      bgOpacity: 0.95,
      pinchToClose: true,
      closeOnVerticalDrag: true
    });
    photoSwipeInstance.init();
  }

  function itemPhotos(item) {
    if (Array.isArray(item.photo_urls) && item.photo_urls.length > 0) {
      return item.photo_urls.filter(Boolean);
    }
    return item.photo_url ? [item.photo_url] : [];
  }

  // Expose for language switcher to trigger full page refresh.
  // sessionStorage caches translations per session — no manual clearing needed.
  window.reloadTranslatedItems = async function() {
    availableOffset = 0;
    soldOffset = 0;
    availableGrid.innerHTML = '';
    soldGrid.innerHTML = '';
    await refreshCategoryLabelCache();
    renderCategoryFilters();
    await loadTab(currentTab);
  };

  document.addEventListener('DOMContentLoaded', async () => {
    await initLanguage();
    document.body.classList.toggle('public-view', !isVolunteer);
    setupTabs();
    setupFilters();
    setupModal();
    setupDelete();
    loadPhotoSwipe();
    await loadPriceBadges();
    renderDonationLegend();
    await loadCategoryFilters();
    loadTab('available');
  });

  function formatBadgeRange(badge) {
    const min = Number(badge.min) || 0;
    if (badge.max === null || badge.max === undefined) {
      return min + '+€';
    }
    return min + '-' + Number(badge.max) + '€';
  }

  function renderDonationLegend() {
    const legend = document.getElementById('donationLegend');
    const items = document.getElementById('donationLegendItems');
    if (!legend || !items) return;
    if (!Array.isArray(priceBadgesConfig) || priceBadgesConfig.length === 0) {
      legend.style.display = 'none';
      return;
    }
    items.innerHTML = '';
    priceBadgesConfig.forEach(badge => {
      const item = document.createElement('span');
      item.className = 'donation-legend-item';
      item.innerHTML =
        '<span class="donation-legend-item-emoji price-badge-' + badge.color + '">' + badge.emoji + '</span>' +
        '<span class="donation-legend-item-range">=' + formatBadgeRange(badge) + '</span>';
      items.appendChild(item);
    });
    legend.style.display = '';
  }

  let categoryLabelCache = {};

  async function loadCategoryFilters() {
    try {
      const data = await apiFetch('/api/categories');
      categoriesData = data.categories || [];
      await refreshCategoryLabelCache();
      renderCategoryFilters();
    } catch (err) {
      console.log('Could not load categories:', err);
    }
  }

  async function refreshCategoryLabelCache() {
    // Collect every raw-Spanish label that needs translation for the current
    // language (custom category/subcategory labels that aren't in sourceStrings).
    if (typeof translateLabels !== 'function') { categoryLabelCache = {}; return; }
    const toTranslate = [];
    categoriesData.forEach(cat => {
      if (cat.groupLabel && t(cat.groupLabel) === cat.groupLabel) toTranslate.push(cat.groupLabel);
      if (cat.subLabel && t(cat.subLabel) === cat.subLabel) toTranslate.push(cat.subLabel);
      // Top-level custom category id (no subLabel) whose id isn't a known UI key
      if (!cat.subLabel && t(cat.id) === cat.id) {
        const lang = getCurrentLang();
        const display = (typeof cat.name === 'object')
          ? (cat.name[lang] || cat.name.es || cat.name.en)
          : cat.name;
        if (display && display !== cat.id) toTranslate.push(display);
      }
    });
    try {
      categoryLabelCache = await translateLabels(toTranslate, getCurrentLang());
    } catch (e) {
      categoryLabelCache = {};
    }
  }

  function translateCustomLabel(text) {
    if (!text) return text;
    return categoryLabelCache[text] || text;
  }

  function renderCategoryFilters() {
    const filters = document.getElementById('filters');
    // Remove all buttons except the "All" button
    const allBtn = filters.querySelector('[data-category="all"]');
    filters.innerHTML = '';
    if (allBtn) {
      allBtn.textContent = t('all');
      allBtn.classList.toggle('active', currentCategory === 'all');
      filters.appendChild(allBtn);
    }

    categoriesData.forEach(cat => {
      const btn = document.createElement('button');
      btn.className = 'filter-btn' + (currentCategory === cat.id ? ' active' : '');
      btn.dataset.category = cat.id;
      btn.textContent = categoryLabel(cat);
      filters.appendChild(btn);
    });
  }

  function categoryLabel(cat) {
    if (cat.subLabel) {
      const group = t(cat.groupLabel);
      const sub = t(cat.subLabel);
      const groupTxt = group !== cat.groupLabel ? group : translateCustomLabel(cat.groupLabel);
      const subTxt = sub !== cat.subLabel ? sub : translateCustomLabel(cat.subLabel);
      return groupTxt + ' > ' + subTxt;
    }
    const translated = t(cat.id);
    if (translated !== cat.id) return translated;
    const lang = getCurrentLang();
    const display = (typeof cat.name === 'object')
      ? (cat.name[lang] || cat.name.es || cat.name.en || cat.id)
      : (cat.name || cat.id);
    return translateCustomLabel(display) || display;
  }

  function categoryLabelById(categoryId) {
    const cat = categoriesData.find(c => c.id === categoryId);
    if (cat) return categoryLabel(cat);
    const translated = t(categoryId);
    return translated !== categoryId ? translated : categoryId;
  }

  // === Tabs ===
  function setupTabs() {
    sectionTabs.addEventListener('click', (e) => {
      const tab = e.target.closest('.section-tab');
      if (!tab) return;
      const section = tab.dataset.section;
      if (section === currentTab) return;

      sectionTabs.querySelectorAll('.section-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      currentTab = section;

      if (section === 'available') {
        availableSection.style.display = '';
        soldSection.style.display = 'none';
        // Reload if grid is empty (first visit to this tab)
        if (availableGrid.children.length === 0) loadTab('available');
      } else {
        availableSection.style.display = 'none';
        soldSection.style.display = '';
        if (soldGrid.children.length === 0) loadTab('sold');
      }
    });
  }

  function setupFilters() {
    document.getElementById('filters').addEventListener('click', (e) => {
      const btn = e.target.closest('.filter-btn');
      if (!btn) return;

      document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentCategory = btn.dataset.category;
      // Reset and reload current tab
      availableOffset = 0;
      soldOffset = 0;
      availableGrid.innerHTML = '';
      soldGrid.innerHTML = '';
      loadTab(currentTab);
    });
  }

  function setupModal() {
    modalClose.addEventListener('click', closeModal);
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });

    // Gallery navigation
    const prevBtn = document.getElementById('modalGalleryPrev');
    const nextBtn = document.getElementById('modalGalleryNext');
    if (prevBtn) prevBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      modalGalleryIndex--;
      renderGallery();
    });
    if (nextBtn) nextBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      modalGalleryIndex++;
      renderGallery();
    });

    // Tap on photo to open fullscreen zoomable viewer
    const modalImg = document.getElementById('modalImg');
    if (modalImg) {
      modalImg.addEventListener('click', (e) => {
        e.stopPropagation();
        if (modalGalleryPhotos.length === 0) return;
        openPhotoSwipe(modalGalleryPhotos, modalGalleryIndex);
      });
    }

    document.addEventListener('keydown', (e) => {
      if (modal.style.display === 'none' || modal.style.display === '') return;
      if (modalGalleryPhotos.length < 2) return;
      if (e.key === 'ArrowLeft') { modalGalleryIndex--; renderGallery(); }
      else if (e.key === 'ArrowRight') { modalGalleryIndex++; renderGallery(); }
    });

    // Swipe support on the gallery
    const galleryEl = document.getElementById('modalGallery');
    if (galleryEl) {
      let touchStartX = 0;
      galleryEl.addEventListener('touchstart', (e) => {
        if (e.changedTouches && e.changedTouches[0]) touchStartX = e.changedTouches[0].screenX;
      }, { passive: true });
      galleryEl.addEventListener('touchend', (e) => {
        if (modalGalleryPhotos.length < 2) return;
        const endX = (e.changedTouches && e.changedTouches[0]) ? e.changedTouches[0].screenX : touchStartX;
        const dx = endX - touchStartX;
        if (Math.abs(dx) < 40) return;
        if (dx < 0) modalGalleryIndex++;
        else modalGalleryIndex--;
        renderGallery();
      }, { passive: true });
    }

    // Modal share button
    const modalShareBtn = document.getElementById('modalShareBtn');
    if (modalShareBtn) {
      modalShareBtn.addEventListener('click', () => {
        if (!currentModalItem) return;
        const price = currentModalItem.final_price || currentModalItem.ai_suggested_price;
        shareItem(currentModalItem, price, modalShareBtn);
      });
    }

    // Reserve toggle
    modalReserveBtn.addEventListener('click', async () => {
      if (!currentModalItem) return;
      modalReserveBtn.disabled = true;
      const newStatus = currentModalItem.status === 'reserved' ? 'available' : 'reserved';
      try {
        await apiFetch('/api/item', {
          method: 'PATCH',
          body: JSON.stringify({ id: currentModalItem.id, status: newStatus })
        });
        closeModal();
        reloadAll();
      } catch (err) {
        alert(err.message || t('actionFailed'));
      } finally {
        modalReserveBtn.disabled = false;
      }
    });

    // Sold button — show sold price modal
    modalSoldBtn.addEventListener('click', () => {
      if (!currentModalItem) return;
      const listedPrice = currentModalItem.final_price || currentModalItem.ai_suggested_price;
      soldPriceInput.value = listedPrice || '';
      soldPriceInput.placeholder = t('soldPricePlaceholder');
      soldPriceModal.style.display = 'flex';
      setTimeout(() => { soldPriceInput.focus(); soldPriceInput.select(); }, 100);
    });

    // Sold price confirm
    soldPriceConfirmBtn.addEventListener('click', async () => {
      if (!currentModalItem) return;
      soldPriceConfirmBtn.disabled = true;
      const soldPrice = parseFloat(soldPriceInput.value) || null;
      try {
        await apiFetch('/api/item', {
          method: 'PATCH',
          body: JSON.stringify({ id: currentModalItem.id, status: 'sold', sold_price: soldPrice })
        });
        soldPriceModal.style.display = 'none';
        closeModal();
        reloadAll();
      } catch (err) {
        alert(err.message || t('actionFailed'));
      } finally {
        soldPriceConfirmBtn.disabled = false;
      }
    });

    // Sold price cancel
    soldPriceCancelBtn.addEventListener('click', () => {
      soldPriceModal.style.display = 'none';
    });

    modalDeleteBtn.addEventListener('click', () => {
      if (!currentModalItem) return;
      deleteItemId = currentModalItem.id;
      deleteModal.style.display = 'flex';
    });
  }

  function setupDelete() {
    deleteCancelBtn.addEventListener('click', () => {
      deleteModal.style.display = 'none';
      deleteItemId = null;
    });

    deleteConfirmBtn.addEventListener('click', async () => {
      if (!deleteItemId) return;
      deleteConfirmBtn.disabled = true;
      try {
        await apiFetch('/api/item', {
          method: 'DELETE',
          body: JSON.stringify({ id: deleteItemId })
        });
        deleteModal.style.display = 'none';
        closeModal();
        reloadAll();
      } catch (err) {
        alert(err.message || t('deleteFailed'));
      } finally {
        deleteConfirmBtn.disabled = false;
        deleteItemId = null;
      }
    });
  }

  function closeModal() {
    modal.style.display = 'none';
    currentModalItem = null;
  }

  function renderGallery() {
    const imgEl = document.getElementById('modalImg');
    const counter = document.getElementById('modalGalleryCounter');
    const dotsEl = document.getElementById('modalGalleryDots');
    const prevBtn = document.getElementById('modalGalleryPrev');
    const nextBtn = document.getElementById('modalGalleryNext');

    if (modalGalleryPhotos.length === 0) {
      imgEl.src = '';
      counter.style.display = 'none';
      dotsEl.innerHTML = '';
      prevBtn.style.display = 'none';
      nextBtn.style.display = 'none';
      return;
    }

    if (modalGalleryIndex < 0) modalGalleryIndex = modalGalleryPhotos.length - 1;
    if (modalGalleryIndex >= modalGalleryPhotos.length) modalGalleryIndex = 0;

    imgEl.src = modalGalleryPhotos[modalGalleryIndex];

    const multi = modalGalleryPhotos.length > 1;
    prevBtn.style.display = multi ? '' : 'none';
    nextBtn.style.display = multi ? '' : 'none';
    counter.style.display = multi ? '' : 'none';
    counter.textContent = `${modalGalleryIndex + 1} / ${modalGalleryPhotos.length}`;

    dotsEl.innerHTML = '';
    if (multi) {
      modalGalleryPhotos.forEach((url, idx) => {
        const dot = document.createElement('button');
        dot.className = 'modal-gallery-dot' + (idx === modalGalleryIndex ? ' active' : '');
        dot.type = 'button';
        dot.setAttribute('aria-label', `Photo ${idx + 1}`);
        dot.addEventListener('click', () => {
          modalGalleryIndex = idx;
          renderGallery();
        });
        dotsEl.appendChild(dot);
      });
    }
  }

  function openModal(item) {
    currentModalItem = item;

    modalGalleryPhotos = itemPhotos(item);
    modalGalleryIndex = 0;
    renderGallery();

    document.getElementById('modalName').textContent = item.description;
    const modalItemPrice = item.final_price || item.ai_suggested_price;

    // Show sold price in modal if available
    const modalPriceEl = document.getElementById('modalPrice');
    if (item.status === 'sold' && item.sold_price != null) {
      modalPriceEl.innerHTML = `${formatPrice(item.sold_price)} <span class="modal-listed-price">${formatPrice(modalItemPrice)}</span>`;
    } else {
      modalPriceEl.textContent = formatPrice(modalItemPrice);
    }
    const modalBadgeEl = document.getElementById('modalBadge');
    const modalBadge = getPriceBadge(modalItemPrice);
    if (modalBadge) {
      modalBadgeEl.textContent = modalBadge.emoji;
      modalBadgeEl.className = 'price-badge modal-price-badge price-badge-' + modalBadge.color;
      modalBadgeEl.style.display = '';
    } else {
      modalBadgeEl.style.display = 'none';
    }

    const cat = document.getElementById('modalCategory');
    cat.textContent = categoryLabelById(item.category);

    const cond = document.getElementById('modalCondition');
    if (item.condition) {
      cond.textContent = formatCondition(item.condition);
      cond.style.display = '';
    } else {
      cond.style.display = 'none';
    }

    const brand = document.getElementById('modalBrand');
    if (item.brand) {
      brand.textContent = item.brand;
      brand.style.display = '';
    } else {
      brand.style.display = 'none';
    }

    document.getElementById('modalReasoning').textContent = item.ai_reasoning || '';

    // Volunteer actions
    if (isVolunteer) {
      modalActions.style.display = '';
      if (item.status === 'available' || item.status === 'reserved') {
        modalReserveBtn.style.display = '';
        modalReserveBtn.textContent = item.status === 'reserved' ? t('unreserve') : t('markReserved');
        modalReserveBtn.className = item.status === 'reserved' ? 'btn btn-sm btn-secondary' : 'btn btn-sm btn-reserve';
      } else {
        modalReserveBtn.style.display = 'none';
      }
      modalSoldBtn.style.display = (item.status === 'available' || item.status === 'reserved') ? '' : 'none';
      modalDeleteBtn.style.display = '';
    } else {
      modalActions.style.display = 'none';
    }

    modal.style.display = 'flex';
  }

  function reloadAll() {
    availableOffset = 0;
    soldOffset = 0;
    availableGrid.innerHTML = '';
    soldGrid.innerHTML = '';
    loadTab(currentTab);
  }

  async function loadTab(tab) {
    const isSold = tab === 'sold';
    const grid = isSold ? soldGrid : availableGrid;
    const emptyEl = isSold ? soldEmpty : availableEmpty;
    const loadMoreEl = isSold ? soldLoadMore : availableLoadMore;

    loading.style.display = '';
    emptyEl.style.display = 'none';

    if (!isSold) {
      // Fetch both available and reserved items in parallel, then translate together
      const [availableData, reservedData] = await Promise.all([
        fetchItems('available'),
        fetchItems('reserved')
      ]);

      // Combine all items for a single translation call to avoid API rate limits
      const allItems = [
        ...availableData.items.map(item => ({ ...item, _status: 'available' })),
        ...reservedData.items.map(item => ({ ...item, _status: 'reserved' }))
      ];

      const translatedItems = await translateItems(allItems, getCurrentLang());

      // Render translated items
      translatedItems.forEach(item => {
        item.status = item._status;
        grid.appendChild(createItemCard(item, item._status));
      });

      availableTotal = availableData.total;
      availableOffset += availableData.items.length;

      loading.style.display = 'none';
      if (availableTotal === 0 && reservedData.items.length === 0) {
        emptyEl.style.display = '';
      }
      loadMoreEl.style.display = availableOffset < availableTotal ? '' : 'none';
    } else {
      await loadItems('sold', grid, true);
      loading.style.display = 'none';
      if (soldTotal === 0) {
        emptyEl.style.display = '';
      }
      loadMoreEl.style.display = soldOffset < soldTotal ? '' : 'none';
    }
  }

  async function fetchItems(status) {
    const offset = status === 'sold' ? soldOffset : (status === 'reserved' ? 0 : availableOffset);
    const params = new URLSearchParams({
      status,
      limit: limit.toString(),
      offset: offset.toString()
    });
    if (currentCategory !== 'all') {
      params.set('category', currentCategory);
    }
    try {
      return await apiFetch('/api/items?' + params);
    } catch (err) {
      console.error(`Failed to fetch ${status} items:`, err);
      return { items: [], total: 0 };
    }
  }

  async function loadItems(status, grid, isSoldTab) {
    try {
      const data = await fetchItems(status);

      // Translate item descriptions before rendering
      const translatedItems = await translateItems(data.items, getCurrentLang());

      translatedItems.forEach(item => {
        item.status = status;
        grid.appendChild(createItemCard(item, status));
      });

      if (status === 'sold') {
        soldTotal = data.total;
        soldOffset += data.items.length;
      } else if (status === 'available') {
        availableTotal = data.total;
        availableOffset += data.items.length;
      }
    } catch (err) {
      console.error(`Failed to load ${status} items:`, err);
    }
  }

  if (availableLoadMoreBtn) {
    availableLoadMoreBtn.addEventListener('click', () => loadItems('available', availableGrid, false).then(() => {
      availableLoadMore.style.display = availableOffset < availableTotal ? '' : 'none';
    }));
  }
  if (soldLoadMoreBtn) {
    soldLoadMoreBtn.addEventListener('click', () => loadItems('sold', soldGrid, true).then(() => {
      soldLoadMore.style.display = soldOffset < soldTotal ? '' : 'none';
    }));
  }

  function createItemCard(item, status) {
    const card = document.createElement('div');
    const cardClass = status === 'sold' ? ' item-card-sold' : (status === 'reserved' ? ' item-card-reserved' : '');
    card.className = 'item-card' + cardClass;
    card.dataset.itemId = item.id;

    const price = item.final_price || item.ai_suggested_price;

    let statusBadge = '';
    if (status === 'sold') {
      statusBadge = `<div class="status-overlay"><span class="status-badge status-badge-sold">${t('sold')}</span></div>`;
    } else if (status === 'reserved') {
      statusBadge = `<div class="status-overlay"><span class="status-badge status-badge-reserved">${t('reserved')}</span></div>`;
    }

    let deleteBtn = '';
    if (isVolunteer) {
      deleteBtn = `<button class="item-delete-btn" title="${t('delete')}">&times;</button>`;
    }

    // Show both listed and sold price for sold items
    let priceHtml;
    if (status === 'sold' && item.sold_price != null) {
      priceHtml = `
        <div class="item-card-price">${formatPrice(item.sold_price)}</div>
        <div class="item-card-listed-price">${formatPrice(price)}</div>
      `;
    } else {
      priceHtml = `<div class="item-card-price">${formatPrice(price)}</div>`;
    }

    const photos = itemPhotos(item);
    const primaryPhoto = photos[0] || item.photo_url || '';
    const multiPhotoBadge = photos.length > 1
      ? `<span class="photo-count-badge" title="${photos.length} photos">&#x1F4F7; ${photos.length}</span>`
      : '';

    card.innerHTML = `
      ${deleteBtn}
      <div class="item-card-img-wrap">
        <img class="item-card-img" src="${escapeHtml(primaryPhoto)}" alt="${escapeHtml(item.description)}" loading="lazy">
        ${multiPhotoBadge}
        ${statusBadge}
      </div>
      <div class="item-card-body">
        <div class="item-card-name">${escapeHtml(item.description)}</div>
        <div class="item-card-footer">
          <div class="item-card-prices">
            ${priceHtml}
          </div>
          <div class="item-card-footer-right">
            ${priceBadgeHtml(price)}
            <button class="share-btn" title="${t('share')}">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="18" cy="5" r="3"/><circle cx="6" cy="12" r="3"/><circle cx="18" cy="19" r="3"/><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"/><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"/></svg>
            </button>
          </div>
        </div>
      </div>
    `;

    card.addEventListener('click', (e) => {
      if (e.target.closest('.item-delete-btn')) return;
      if (e.target.closest('.share-btn')) return;
      openModal(item);
    });

    const shareBtn = card.querySelector('.share-btn');
    if (shareBtn) {
      shareBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        shareItem(item, price, shareBtn);
      });
    }

    const delBtn = card.querySelector('.item-delete-btn');
    if (delBtn) {
      delBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        deleteItemId = item.id;
        deleteModal.style.display = 'flex';
      });
    }

    return card;
  }

  function shareItem(item, price, btn) {
    const shareUrl = window.location.origin + '/shop/' + item.id;
    const shareData = {
      title: item.description,
      text: item.description + ' - ' + formatPrice(price),
      url: shareUrl
    };
    if (navigator.share) {
      navigator.share(shareData).catch(() => {});
    } else {
      navigator.clipboard.writeText(shareUrl).then(() => {
        btn.classList.add('share-btn-copied');
        setTimeout(() => btn.classList.remove('share-btn-copied'), 1500);
      }).catch(() => {});
    }
  }

  function escapeHtml(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
  }
})();
