// === Unified Translation System ===
// Architecture: English source → LLM translation → localStorage cache
// All languages (including Spanish) go through the same pipeline.
// Spanish is pre-seeded for instant first load / offline resilience.

const TRANSLATION_VERSION = 4; // Bump when sourceStrings change to invalidate caches

// === English Source Strings (single source of truth) ===
const sourceStrings = {
  tagline: 'Solidarity shop with fair prices',
  heroTitle: 'Give things a second life',
  heroSubtitle: 'Second-hand items at fair prices, valued with artificial intelligence',
  browseShop: 'Browse shop',
  volunteers: 'Volunteers',
  browseShopDesc: 'Discover available items',
  volunteerAccess: 'Volunteer access',
  volunteerAccessDesc: 'Price and manage items',
  shopInfo: 'Shop information',
  address: 'Address',
  hours: 'Hours',
  phone: 'Phone',
  footerText: 'Made with love for the community',
  footerCredit: 'by',
  all: 'All',
  clothes: 'Clothes',
  electronics: 'Electronics',
  furniture: 'Furniture',
  books: 'Books',
  toys: 'Toys',
  other: 'Other',
  loading: 'Loading...',
  loadMore: 'Load more',
  noItems: 'No items available in this category',
  availableItems: 'Available items',
  soldItems: 'Sold items',
  sold: 'Sold',
  deleteItem: 'Delete item',
  confirmDelete: 'Delete this item?',
  deleteWarning: 'This action cannot be undone',
  reserved: 'Reserved',
  markReserved: 'Reserve',
  unreserve: 'Unreserve',
  markSold: 'Sold',
  enterSoldPrice: 'Enter the actual selling price',
  soldPriceLabel: 'Sold for',
  listedPriceLabel: 'Listed',
  soldPricePlaceholder: 'Selling price',
  confirm: 'Confirm',
  noSoldItems: 'No sold items yet',
  otherNotListed: 'Other / Not listed',
  cancel: 'Cancel',
  delete: 'Delete',
  enterPin: 'Enter PIN',
  enter: 'Enter',
  wrongPin: 'Wrong PIN',
  priceItem: 'Price an item',
  takePhoto: 'Take photo',
  uploadPhoto: 'Upload image',
  photoCountHint: 'Add up to 5 photos for a better AI analysis',
  maxPhotosReached: 'Maximum of {max} photos reached',
  analyzePhotos: 'Analyze with AI',
  analyzing: 'Analyzing with AI...',
  multipleItems: 'Multiple items detected',
  selectItem: 'Select which one to price:',
  marketPrice: 'Market price',
  recommendedPrice: 'Recommended price',
  finalPrice: 'Final price (€):',
  saveItem: 'Save item',
  discard: 'Discard',
  skipAi: 'Set price manually',
  manualPricing: 'Manual pricing',
  manualPricingDesc: 'AI could not estimate the price. Enter the details manually.',
  itemDescription: 'Description:',
  categoryLabel: 'Category:',
  priceEuro: 'Price (€):',
  enterDescription: 'Enter a description',
  enterPrice: 'Enter a price',
  itemSaved: 'Item saved successfully',
  newItem: 'Price another item',
  todayItems: "Today's items",
  noTodayItems: 'No items today',
  condition_like_new: 'Like new',
  condition_good: 'Good',
  condition_fair: 'Fair',
  condition_worn: 'Worn',
  confidence_high: 'High confidence',
  confidence_medium: 'Medium confidence',
  confidence_low: 'Low confidence',
  takeAnotherPhoto: 'Take another photo',
  selectMaterials: 'Select the materials:',
  selectCondition: 'Item condition:',
  estimatePrice: 'Estimate price',
  selectAtLeastOneMaterial: 'Select at least one material',
  unknownItem: 'Unidentified item',
  material_wood: 'Wood',
  material_metal: 'Metal',
  material_plastic: 'Plastic',
  material_fabric: 'Fabric',
  material_leather: 'Leather',
  material_glass: 'Glass',
  material_ceramic: 'Ceramic',
  material_rubber: 'Rubber',
  material_paper: 'Paper',
  material_stone: 'Stone',
  material_other: 'Other',
  manageCategories: 'Manage categories',
  addCategory: 'Add category',
  add: 'Add',
  confirmDeleteCategory: 'Delete this category?',
  categoryExists: 'This category already exists',
  enterCategoryName: 'Enter a category name',
  categoryPlaceholder: 'Category (e.g. Kitchen)',
  subcategoryPlaceholder: 'Subcategory (optional)',
  translating: 'Translating...',
  serviceOverloadTitle: 'Service temporarily unavailable',
  serviceOverloadMsg: 'Translation is temporarily unavailable due to high demand. The page is shown in English for now — please try changing the language again later or tomorrow.',
  dismiss: 'OK',
  shareText: 'Second-hand items at fair prices!',
  linkCopied: 'Link copied!',
  share: 'Share',
  installApp: 'Install app',
  analysisFailed: 'Analysis failed. Please try again.',
  pricingFailed: 'Pricing failed. Please try again.',
  saveFailed: 'Failed to save item',
  deleteFailed: 'Failed to delete',
  actionFailed: 'Action failed',
  noPhoto: 'No photo',
  manualPricingReasoning: 'Manual pricing by volunteer',
  manageBadges: 'Manage price badges',
  badgesSaved: 'Badges saved',
  badgeFrom: 'From',
  badgeTo: 'To',
  badgeNoLimit: 'No limit',
  saveBadges: 'Save',
  recommendedDonations: 'recommended donations',
  rastroSolidario: 'Solidarity Flea Market',
  shopPageTitle: 'Love Me Again — Shop',
  volunteerPageTitle: 'Love Me Again — Volunteers',
  homePageTitle: 'Love Me Again — Solidarity Flea Market',
  workshops: 'Workshops',
  events: 'Events',
  workshopsPageTitle: 'Love Me Again — Workshops',
  eventsPageTitle: 'Love Me Again — Events',
  upcoming: 'Upcoming',
  past: 'Past',
  noUpcomingEvents: 'No upcoming events',
  noPastEvents: 'The archive is empty',
  free: 'Free',
  requirements: 'What to bring',
  contact: 'Contact',
  manageAgenda: 'Manage workshops and events',
  eventTitle: 'Title',
  startsAt: 'Starts',
  endsAt: 'Ends',
  comingSoon: '- coming soon -',
  comingSoonToggle: '- coming soon - (date TBD)',
  location: 'Location',
  locationPlaceholder: 'Address or room',
  description: 'Description',
  priceEuroOrFree: 'Price (€)',
  priceOrFreePlaceholder: 'Empty = free',
  capacity: 'Seats',
  organizer: 'Hosted by',
  contactPlaceholder: 'Phone, Telegram or link',
  videoUrl: 'Video URL (YouTube / Vimeo)',
  addPhotos: 'Add photos',
  saveEvent: 'Save',
  updateEvent: 'Update',
  existingEvents: 'Existing entries',
  noEvents: 'No entries yet',
  edit: 'Edit',
  enterTitle: 'Enter a title',
  enterStartsAt: 'Pick a start date and time',
  confirmDeleteEvent: 'Delete this entry?',
  eventSaved: 'Entry saved'
};

// === Spanish Pre-seeded Translations (offline resilience) ===
const spanishStrings = {
  tagline: 'Tienda solidaria con precios justos',
  heroTitle: 'Dale una segunda vida a las cosas',
  heroSubtitle: 'Artículos de segunda mano a precios solidarios, valorados con inteligencia artificial',
  browseShop: 'Ver la tienda',
  volunteers: 'Voluntarios',
  browseShopDesc: 'Descubre artículos disponibles',
  volunteerAccess: 'Acceso voluntarios',
  volunteerAccessDesc: 'Valorar y gestionar artículos',
  shopInfo: 'Información de la tienda',
  address: 'Dirección',
  hours: 'Horario',
  phone: 'Teléfono',
  footerText: 'Hecho con amor para la comunidad',
  footerCredit: 'por',
  all: 'Todos',
  clothes: 'Ropa',
  electronics: 'Electrónica',
  furniture: 'Muebles',
  books: 'Libros',
  toys: 'Juguetes',
  other: 'Otros',
  loading: 'Cargando...',
  loadMore: 'Cargar más',
  noItems: 'No hay artículos disponibles en esta categoría',
  availableItems: 'Artículos disponibles',
  soldItems: 'Artículos vendidos',
  sold: 'Vendido',
  deleteItem: 'Eliminar artículo',
  confirmDelete: '¿Eliminar este artículo?',
  deleteWarning: 'Esta acción no se puede deshacer',
  reserved: 'Reservado',
  markReserved: 'Reservar',
  unreserve: 'Quitar reserva',
  markSold: 'Vendido',
  enterSoldPrice: 'Introduce el precio de venta real',
  soldPriceLabel: 'Vendido por',
  listedPriceLabel: 'Precio lista',
  soldPricePlaceholder: 'Precio de venta',
  confirm: 'Confirmar',
  noSoldItems: 'No hay artículos vendidos todavía',
  otherNotListed: 'Otro / No aparece en la lista',
  cancel: 'Cancelar',
  delete: 'Eliminar',
  enterPin: 'Introduce el PIN',
  enter: 'Entrar',
  wrongPin: 'PIN incorrecto',
  priceItem: 'Valorar artículo',
  takePhoto: 'Tomar foto',
  uploadPhoto: 'Subir imagen',
  photoCountHint: 'Añade hasta 5 fotos para un mejor análisis con IA',
  maxPhotosReached: 'Máximo de {max} fotos alcanzado',
  analyzePhotos: 'Analizar con IA',
  analyzing: 'Analizando con IA...',
  multipleItems: 'Se detectaron varios artículos',
  selectItem: 'Selecciona cuál quieres valorar:',
  marketPrice: 'Precio mercado',
  recommendedPrice: 'Precio recomendado',
  finalPrice: 'Precio final (€):',
  saveItem: 'Guardar artículo',
  discard: 'Descartar',
  skipAi: 'Poner precio manual',
  manualPricing: 'Precio manual',
  manualPricingDesc: 'La IA no pudo estimar el precio. Introduce los datos manualmente.',
  itemDescription: 'Descripción:',
  categoryLabel: 'Categoría:',
  priceEuro: 'Precio (€):',
  enterDescription: 'Introduce una descripción',
  enterPrice: 'Introduce un precio',
  itemSaved: 'Artículo guardado correctamente',
  newItem: 'Valorar otro artículo',
  todayItems: 'Artículos de hoy',
  noTodayItems: 'No hay artículos hoy',
  condition_like_new: 'Como nuevo',
  condition_good: 'Bueno',
  condition_fair: 'Aceptable',
  condition_worn: 'Usado',
  confidence_high: 'Alta confianza',
  confidence_medium: 'Confianza media',
  confidence_low: 'Baja confianza',
  takeAnotherPhoto: 'Tomar otra foto',
  selectMaterials: 'Selecciona los materiales:',
  selectCondition: 'Estado del artículo:',
  estimatePrice: 'Estimar precio',
  selectAtLeastOneMaterial: 'Selecciona al menos un material',
  unknownItem: 'Artículo no identificado',
  material_wood: 'Madera',
  material_metal: 'Metal',
  material_plastic: 'Plástico',
  material_fabric: 'Tela',
  material_leather: 'Cuero',
  material_glass: 'Vidrio',
  material_ceramic: 'Cerámica',
  material_rubber: 'Goma',
  material_paper: 'Papel',
  material_stone: 'Piedra',
  material_other: 'Otro',
  manageCategories: 'Gestionar categorías',
  addCategory: 'Añadir categoría',
  add: 'Añadir',
  confirmDeleteCategory: '¿Eliminar esta categoría?',
  categoryExists: 'Esta categoría ya existe',
  enterCategoryName: 'Introduce un nombre de categoría',
  categoryPlaceholder: 'Categoría (ej: Cocina)',
  subcategoryPlaceholder: 'Subcategoría (opcional)',
  translating: 'Traduciendo...',
  serviceOverloadTitle: 'Servicio temporalmente no disponible',
  serviceOverloadMsg: 'La traducción no está disponible temporalmente por alta demanda. La página se muestra en inglés por ahora — inténtalo más tarde o mañana.',
  dismiss: 'OK',
  shareText: '¡Artículos de segunda mano a precios justos!',
  linkCopied: '¡Enlace copiado!',
  share: 'Compartir',
  installApp: 'Instalar app',
  analysisFailed: 'El análisis falló. Inténtalo de nuevo.',
  pricingFailed: 'Error al estimar precio. Inténtalo de nuevo.',
  saveFailed: 'Error al guardar el artículo',
  deleteFailed: 'Error al eliminar',
  actionFailed: 'La acción falló',
  noPhoto: 'Sin foto',
  manualPricingReasoning: 'Precio manual por voluntario',
  manageBadges: 'Gestionar insignias de precio',
  badgesSaved: 'Insignias guardadas',
  badgeFrom: 'Desde',
  badgeTo: 'Hasta',
  badgeNoLimit: 'Sin límite',
  saveBadges: 'Guardar',
  recommendedDonations: 'donaciones recomendadas',
  rastroSolidario: 'Rastro Solidario',
  shopPageTitle: 'Love Me Again — Tienda',
  volunteerPageTitle: 'Love Me Again — Voluntarios',
  homePageTitle: 'Love Me Again — Rastro Solidario',
  workshops: 'Talleres',
  events: 'Eventos',
  workshopsPageTitle: 'Love Me Again — Talleres',
  eventsPageTitle: 'Love Me Again — Eventos',
  upcoming: 'Próximos',
  past: 'Pasados',
  noUpcomingEvents: 'No hay eventos próximos',
  noPastEvents: 'El archivo está vacío',
  free: 'Gratis',
  requirements: 'Qué traer',
  contact: 'Contacto',
  manageAgenda: 'Gestionar talleres y eventos',
  eventTitle: 'Título',
  startsAt: 'Comienza',
  endsAt: 'Termina',
  comingSoon: '- próximamente -',
  comingSoonToggle: '- próximamente - (fecha por confirmar)',
  location: 'Lugar',
  locationPlaceholder: 'Dirección o sala',
  description: 'Descripción',
  priceEuroOrFree: 'Precio (€)',
  priceOrFreePlaceholder: 'Vacío = gratis',
  capacity: 'Plazas',
  organizer: 'Organiza',
  contactPlaceholder: 'Teléfono, Telegram o enlace',
  videoUrl: 'Video URL (YouTube / Vimeo)',
  addPhotos: 'Añadir fotos',
  saveEvent: 'Guardar',
  updateEvent: 'Actualizar',
  existingEvents: 'Entradas existentes',
  noEvents: 'Todavía no hay entradas',
  edit: 'Editar',
  enterTitle: 'Introduce un título',
  enterStartsAt: 'Elige fecha y hora de inicio',
  confirmDeleteEvent: '¿Eliminar esta entrada?',
  eventSaved: 'Entrada guardada'
};

// === German Pre-seeded Translations ===
const germanStrings = {
  tagline: 'Solidaritätsladen mit fairen Preisen',
  heroTitle: 'Gib Dingen ein zweites Leben',
  heroSubtitle: 'Second-Hand-Artikel zu fairen Preisen, bewertet mit künstlicher Intelligenz',
  browseShop: 'Laden durchstöbern',
  volunteers: 'Freiwillige',
  browseShopDesc: 'Verfügbare Artikel entdecken',
  volunteerAccess: 'Freiwilligen-Zugang',
  volunteerAccessDesc: 'Artikel bewerten und verwalten',
  shopInfo: 'Laden-Information',
  address: 'Adresse',
  hours: 'Öffnungszeiten',
  phone: 'Telefon',
  footerText: 'Mit Liebe für die Gemeinschaft gemacht',
  footerCredit: 'von',
  all: 'Alle',
  clothes: 'Kleidung',
  electronics: 'Elektronik',
  furniture: 'Möbel',
  books: 'Bücher',
  toys: 'Spielzeug',
  other: 'Sonstiges',
  loading: 'Laden...',
  loadMore: 'Mehr laden',
  noItems: 'Keine Artikel in dieser Kategorie verfügbar',
  availableItems: 'Verfügbare Artikel',
  soldItems: 'Verkaufte Artikel',
  sold: 'Verkauft',
  deleteItem: 'Artikel löschen',
  confirmDelete: 'Diesen Artikel löschen?',
  deleteWarning: 'Diese Aktion kann nicht rückgängig gemacht werden',
  reserved: 'Reserviert',
  markReserved: 'Reservieren',
  unreserve: 'Reservierung aufheben',
  markSold: 'Verkauft',
  enterSoldPrice: 'Geben Sie den tatsächlichen Verkaufspreis ein',
  soldPriceLabel: 'Verkauft für',
  listedPriceLabel: 'Listenpreis',
  soldPricePlaceholder: 'Verkaufspreis',
  confirm: 'Bestätigen',
  noSoldItems: 'Noch keine verkauften Artikel',
  otherNotListed: 'Anderes / Nicht aufgeführt',
  cancel: 'Abbrechen',
  delete: 'Löschen',
  enterPin: 'PIN eingeben',
  enter: 'Eingeben',
  wrongPin: 'Falsche PIN',
  priceItem: 'Artikel bewerten',
  takePhoto: 'Foto aufnehmen',
  uploadPhoto: 'Bild hochladen',
  photoCountHint: 'Fügen Sie bis zu 5 Fotos für eine bessere KI-Analyse hinzu',
  maxPhotosReached: 'Maximum von {max} Fotos erreicht',
  analyzePhotos: 'Mit KI analysieren',
  analyzing: 'Analyse mit KI...',
  multipleItems: 'Mehrere Artikel erkannt',
  selectItem: 'Welchen möchten Sie bewerten:',
  marketPrice: 'Marktpreis',
  recommendedPrice: 'Empfohlener Preis',
  finalPrice: 'Endpreis (€):',
  saveItem: 'Artikel speichern',
  discard: 'Verwerfen',
  skipAi: 'Preis manuell festlegen',
  manualPricing: 'Manuelle Preisfestlegung',
  manualPricingDesc: 'Die KI konnte den Preis nicht schätzen. Geben Sie die Daten manuell ein.',
  itemDescription: 'Beschreibung:',
  categoryLabel: 'Kategorie:',
  priceEuro: 'Preis (€):',
  enterDescription: 'Beschreibung eingeben',
  enterPrice: 'Preis eingeben',
  itemSaved: 'Artikel erfolgreich gespeichert',
  newItem: 'Weiteren Artikel bewerten',
  todayItems: 'Heutige Artikel',
  noTodayItems: 'Heute keine Artikel',
  condition_like_new: 'Wie neu',
  condition_good: 'Gut',
  condition_fair: 'Akzeptabel',
  condition_worn: 'Gebraucht',
  confidence_high: 'Hohe Sicherheit',
  confidence_medium: 'Mittlere Sicherheit',
  confidence_low: 'Geringe Sicherheit',
  takeAnotherPhoto: 'Weiteres Foto aufnehmen',
  selectMaterials: 'Materialien auswählen:',
  selectCondition: 'Zustand des Artikels:',
  estimatePrice: 'Preis schätzen',
  selectAtLeastOneMaterial: 'Mindestens ein Material auswählen',
  unknownItem: 'Nicht identifizierter Artikel',
  material_wood: 'Holz',
  material_metal: 'Metall',
  material_plastic: 'Kunststoff',
  material_fabric: 'Stoff',
  material_leather: 'Leder',
  material_glass: 'Glas',
  material_ceramic: 'Keramik',
  material_rubber: 'Gummi',
  material_paper: 'Papier',
  material_stone: 'Stein',
  material_other: 'Sonstiges',
  manageCategories: 'Kategorien verwalten',
  addCategory: 'Kategorie hinzufügen',
  add: 'Hinzufügen',
  confirmDeleteCategory: 'Diese Kategorie löschen?',
  categoryExists: 'Diese Kategorie existiert bereits',
  enterCategoryName: 'Kategorienamen eingeben',
  categoryPlaceholder: 'Kategorie (z.B. Küche)',
  subcategoryPlaceholder: 'Unterkategorie (optional)',
  translating: 'Übersetzen...',
  serviceOverloadTitle: 'Dienst vorübergehend nicht verfügbar',
  serviceOverloadMsg: 'Die Übersetzung ist wegen hoher Nachfrage vorübergehend nicht verfügbar. Die Seite wird vorerst auf Englisch angezeigt — bitte versuchen Sie es später oder morgen erneut.',
  dismiss: 'OK',
  shareText: 'Second-Hand-Artikel zu fairen Preisen!',
  linkCopied: 'Link kopiert!',
  share: 'Teilen',
  installApp: 'App installieren',
  analysisFailed: 'Analyse fehlgeschlagen. Bitte versuchen Sie es erneut.',
  pricingFailed: 'Preisschätzung fehlgeschlagen. Bitte versuchen Sie es erneut.',
  saveFailed: 'Artikel konnte nicht gespeichert werden',
  deleteFailed: 'Löschen fehlgeschlagen',
  actionFailed: 'Aktion fehlgeschlagen',
  noPhoto: 'Kein Foto',
  manualPricingReasoning: 'Manuelle Preisfestlegung durch Freiwillige',
  manageBadges: 'Preisabzeichen verwalten',
  badgesSaved: 'Abzeichen gespeichert',
  badgeFrom: 'Von',
  badgeTo: 'Bis',
  badgeNoLimit: 'Kein Limit',
  saveBadges: 'Speichern',
  recommendedDonations: 'empfohlene Spenden',
  rastroSolidario: 'Solidaritätsflohmarkt',
  shopPageTitle: 'Love Me Again — Laden',
  volunteerPageTitle: 'Love Me Again — Freiwillige',
  homePageTitle: 'Love Me Again — Solidaritätsflohmarkt',
  workshops: 'Workshops',
  events: 'Veranstaltungen',
  workshopsPageTitle: 'Love Me Again — Workshops',
  eventsPageTitle: 'Love Me Again — Veranstaltungen',
  upcoming: 'Bevorstehend',
  past: 'Vergangen',
  noUpcomingEvents: 'Keine bevorstehenden Termine',
  noPastEvents: 'Das Archiv ist leer',
  free: 'Kostenlos',
  requirements: 'Mitzubringen',
  contact: 'Kontakt',
  manageAgenda: 'Workshops und Veranstaltungen verwalten',
  eventTitle: 'Titel',
  startsAt: 'Beginn',
  endsAt: 'Ende',
  comingSoon: '- demnächst -',
  comingSoonToggle: '- demnächst - (Datum folgt)',
  location: 'Ort',
  locationPlaceholder: 'Adresse oder Raum',
  description: 'Beschreibung',
  priceEuroOrFree: 'Preis (€)',
  priceOrFreePlaceholder: 'Leer = kostenlos',
  capacity: 'Plätze',
  organizer: 'Veranstaltet von',
  contactPlaceholder: 'Telefon, Telegram oder Link',
  videoUrl: 'Video-URL (YouTube / Vimeo)',
  addPhotos: 'Fotos hinzufügen',
  saveEvent: 'Speichern',
  updateEvent: 'Aktualisieren',
  existingEvents: 'Bestehende Einträge',
  noEvents: 'Noch keine Einträge',
  edit: 'Bearbeiten',
  enterTitle: 'Titel eingeben',
  enterStartsAt: 'Startdatum und -zeit wählen',
  confirmDeleteEvent: 'Diesen Eintrag löschen?',
  eventSaved: 'Eintrag gespeichert'
};

// === Pre-seeded translations map ===
// All languages are pre-seeded from translations-data.js — no API calls needed for UI strings
const preSeededTranslations = {
  es: spanishStrings,
  de: germanStrings,
  zh: zhStrings,
  ar: arStrings,
  ro: roStrings,
  uk: ukStrings,
  bg: bgStrings,
  hi: hiStrings,
  bn: bnStrings,
  ur: urStrings,
  tl: tlStrings,
  sw: swStrings,
  wo: woStrings,
  ha: haStrings,
  ko: koStrings,
  ja: jaStrings,
  vi: viStrings,
  th: thStrings,
  fr: frStrings,
  it: itStrings,
  pt: ptStrings,
  ca: caStrings,
  gl: glStrings,
  nl: nlStrings,
  sv: svStrings,
  da: daStrings,
  no: noStrings,
  is: isStrings,
  ru: ruStrings,
  pl: plStrings,
  cs: csStrings,
  sk: skStrings,
  hr: hrStrings,
  sr: srStrings,
  bs: bsStrings,
  sl: slStrings,
  mk: mkStrings,
  be: beStrings,
  lt: ltStrings,
  lv: lvStrings,
  fi: fiStrings,
  et: etStrings,
  hu: huStrings,
  el: elStrings,
  sq: sqStrings,
  tr: trStrings,
  mt: mtStrings,
  ga: gaStrings,
  cy: cyStrings,
  eu: euStrings
};

// === Language List ===
// Structure: Main → Immigration communities → All European (incl. Baltics)
const allLanguages = [
  // Main languages
  { code: 'en', name: 'English', countryCode: 'gb', englishName: 'English' },
  { code: 'es', name: 'Español', countryCode: 'es', englishName: 'Spanish' },
  { code: 'de', name: 'Deutsch', countryCode: 'de', englishName: 'German' },
  { code: 'zh', name: '中文', countryCode: 'cn', englishName: 'Chinese' },
  { code: 'divider' },
  // Immigration communities (Spain)
  { code: 'ar', name: 'العربية', countryCode: 'ma', englishName: 'Arabic' },
  { code: 'ro', name: 'Română', countryCode: 'ro', englishName: 'Romanian' },
  { code: 'uk', name: 'Українська', countryCode: 'ua', englishName: 'Ukrainian' },
  { code: 'bg', name: 'Български', countryCode: 'bg', englishName: 'Bulgarian' },
  { code: 'hi', name: 'हिन्दी', countryCode: 'in', englishName: 'Hindi' },
  { code: 'bn', name: 'বাংলা', countryCode: 'bd', englishName: 'Bengali' },
  { code: 'ur', name: 'اردو', countryCode: 'pk', englishName: 'Urdu' },
  { code: 'tl', name: 'Tagalog', countryCode: 'ph', englishName: 'Tagalog' },
  { code: 'sw', name: 'Kiswahili', countryCode: 'ke', englishName: 'Swahili' },
  { code: 'wo', name: 'Wolof', countryCode: 'sn', englishName: 'Wolof' },
  { code: 'ha', name: 'Hausa', countryCode: 'ng', englishName: 'Hausa' },
  { code: 'ko', name: '한국어', countryCode: 'kr', englishName: 'Korean' },
  { code: 'ja', name: '日本語', countryCode: 'jp', englishName: 'Japanese' },
  { code: 'vi', name: 'Tiếng Việt', countryCode: 'vn', englishName: 'Vietnamese' },
  { code: 'th', name: 'ไทย', countryCode: 'th', englishName: 'Thai' },
  { code: 'divider' },
  // All European languages (Romance)
  { code: 'fr', name: 'Français', countryCode: 'fr', englishName: 'French' },
  { code: 'it', name: 'Italiano', countryCode: 'it', englishName: 'Italian' },
  { code: 'pt', name: 'Português', countryCode: 'pt', englishName: 'Portuguese' },
  { code: 'ca', name: 'Català', countryCode: 'ad', englishName: 'Catalan' },
  { code: 'gl', name: 'Galego', countryCode: 'es', englishName: 'Galician' },
  // Germanic
  { code: 'nl', name: 'Nederlands', countryCode: 'nl', englishName: 'Dutch' },
  { code: 'sv', name: 'Svenska', countryCode: 'se', englishName: 'Swedish' },
  { code: 'da', name: 'Dansk', countryCode: 'dk', englishName: 'Danish' },
  { code: 'no', name: 'Norsk', countryCode: 'no', englishName: 'Norwegian' },
  { code: 'is', name: 'Íslenska', countryCode: 'is', englishName: 'Icelandic' },
  // Slavic
  { code: 'ru', name: 'Русский', countryCode: 'ru', englishName: 'Russian' },
  { code: 'pl', name: 'Polski', countryCode: 'pl', englishName: 'Polish' },
  { code: 'cs', name: 'Čeština', countryCode: 'cz', englishName: 'Czech' },
  { code: 'sk', name: 'Slovenčina', countryCode: 'sk', englishName: 'Slovak' },
  { code: 'hr', name: 'Hrvatski', countryCode: 'hr', englishName: 'Croatian' },
  { code: 'sr', name: 'Srpski', countryCode: 'rs', englishName: 'Serbian' },
  { code: 'bs', name: 'Bosanski', countryCode: 'ba', englishName: 'Bosnian' },
  { code: 'sl', name: 'Slovenščina', countryCode: 'si', englishName: 'Slovenian' },
  { code: 'mk', name: 'Македонски', countryCode: 'mk', englishName: 'Macedonian' },
  { code: 'be', name: 'Беларуская', countryCode: 'by', englishName: 'Belarusian' },
  // Baltic
  { code: 'lt', name: 'Lietuvių', countryCode: 'lt', englishName: 'Lithuanian' },
  { code: 'lv', name: 'Latviešu', countryCode: 'lv', englishName: 'Latvian' },
  // Finno-Ugric
  { code: 'fi', name: 'Suomi', countryCode: 'fi', englishName: 'Finnish' },
  { code: 'et', name: 'Eesti', countryCode: 'ee', englishName: 'Estonian' },
  { code: 'hu', name: 'Magyar', countryCode: 'hu', englishName: 'Hungarian' },
  // Other European
  { code: 'el', name: 'Ελληνικά', countryCode: 'gr', englishName: 'Greek' },
  { code: 'sq', name: 'Shqip', countryCode: 'al', englishName: 'Albanian' },
  { code: 'tr', name: 'Türkçe', countryCode: 'tr', englishName: 'Turkish' },
  { code: 'mt', name: 'Malti', countryCode: 'mt', englishName: 'Maltese' },
  { code: 'ga', name: 'Gaeilge', countryCode: 'ie', englishName: 'Irish' },
  { code: 'cy', name: 'Cymraeg', countryCode: 'gb-wls', englishName: 'Welsh' },
  { code: 'eu', name: 'Euskara', countryCode: 'es', englishName: 'Basque' }
];

// === State ===
let currentTranslations = null;

// === Core Functions ===

function getCurrentLang() {
  return localStorage.getItem('lang') || 'es';
}

function t(key) {
  if (currentTranslations && currentTranslations[key]) {
    return currentTranslations[key];
  }
  return sourceStrings[key] || key;
}

function getLanguageInfo(code) {
  return allLanguages.find(l => l.code === code) || allLanguages[0];
}

// === Translation Loading ===

async function loadTranslations(code) {
  // English = source strings, no translation needed
  if (code === 'en') {
    currentTranslations = sourceStrings;
    return;
  }

  // Pre-seeded languages: use built-in translations as the base, then fill
  // in any sourceStrings keys missing from the pre-seed (keys added after
  // that language was last hand-translated) via a one-time API fetch cached
  // in localStorage. Keeps offline-first UX while preventing English leaks.
  if (preSeededTranslations[code]) {
    await loadPreSeededWithExtras(code);
    return;
  }

  // All other languages: cache-first, then API
  const cacheKey = 'translations_' + code;
  const cached = localStorage.getItem(cacheKey);
  if (cached) {
    try {
      const data = JSON.parse(cached);
      if (data.version === TRANSLATION_VERSION) {
        currentTranslations = data.strings;
        return;
      }
    } catch (e) { /* cache corrupted, re-fetch */ }
  }

  // Fetch from API
  const langInfo = getLanguageInfo(code);
  showTranslationOverlay();
  try {
    const result = await apiFetch('/api/translate', {
      method: 'POST',
      body: JSON.stringify({
        type: 'ui',
        targetLanguage: langInfo.englishName,
        strings: sourceStrings
      })
    });

    if (result.translations) {
      currentTranslations = result.translations;
      localStorage.setItem(cacheKey, JSON.stringify({
        version: TRANSLATION_VERSION,
        strings: currentTranslations
      }));
    } else {
      currentTranslations = sourceStrings; // fallback to English
    }
  } catch (err) {
    console.error('Translation failed:', err);
    currentTranslations = sourceStrings; // fallback to English
    // Show non-blocking toast and schedule background retry
    var isRateLimit = err.message && (err.message.includes('429') || err.message.includes('overload') || err.message.includes('unavailable'));
    if (isRateLimit) {
      showServiceOverloadModal();
      // Retry in background after 10 seconds
      setTimeout(function() { retryTranslationInBackground(code, langInfo, cacheKey); }, 10000);
    }
  } finally {
    hideTranslationOverlay();
  }
}

async function loadPreSeededWithExtras(code) {
  const preSeed = preSeededTranslations[code];
  const combined = Object.assign({}, preSeed);

  const missingKeys = Object.keys(sourceStrings).filter(k => !(k in combined));

  // Apply any previously-cached API-translated extras
  const extrasKey = 'translations_extra_' + code;
  let cachedExtras = {};
  try {
    const raw = localStorage.getItem(extrasKey);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (parsed && parsed.version === TRANSLATION_VERSION && parsed.strings) {
        cachedExtras = parsed.strings;
      }
    }
  } catch (e) { /* cache corrupted, ignore */ }

  missingKeys.forEach(k => {
    if (cachedExtras[k]) combined[k] = cachedExtras[k];
  });

  currentTranslations = combined;

  const stillMissing = missingKeys.filter(k => !(k in combined));
  if (stillMissing.length === 0) return;

  // Kick off a background fetch for keys missing from both pre-seed and
  // extras cache. Do NOT await — pre-seeded languages should render
  // instantly; remaining keys fall back to English source via t() until
  // the fetch completes, then we re-apply translations in place.
  fetchMissingPreSeedKeys(code, stillMissing, cachedExtras, extrasKey, combined);
}

// === Translation HTTP helper with retry ===
// Wraps apiFetch('/api/translate', ...) with up to 2 client-side retries on
// network / 429 / 500-class failures. The server also retries internally;
// these retries cover transport-level issues the server never sees. When
// every attempt fails we return null so callers skip caching and try again
// on the next page load.
async function translateApi(targetLanguage, type, strings) {
  const maxRetries = 2;
  let lastError = null;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const result = await apiFetch('/api/translate', {
        method: 'POST',
        body: JSON.stringify({ type: type, targetLanguage: targetLanguage, strings: strings })
      });
      if (result && result.translations && typeof result.translations === 'object') {
        return result.translations;
      }
      lastError = new Error('Empty translations in response');
    } catch (err) {
      lastError = err;
    }
    if (attempt < maxRetries) {
      await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
    }
  }
  console.warn('[translateApi] All retries failed:', lastError && (lastError.message || lastError));
  return null;
}

async function fetchMissingPreSeedKeys(code, missingKeys, cachedExtras, extrasKey, combined) {
  const langInfo = getLanguageInfo(code);
  const toTranslate = {};
  missingKeys.forEach(k => { toTranslate[k] = sourceStrings[k]; });

  const translations = await translateApi(langInfo.englishName, 'ui', toTranslate);

  // User may have switched languages while the request was in flight
  if (getCurrentLang() !== code) return;
  if (!translations) return;

  Object.keys(translations).forEach(k => {
    if (translations[k] && String(translations[k]).trim()) {
      combined[k] = translations[k];
    }
  });
  currentTranslations = combined;

  const mergedExtras = Object.assign({}, cachedExtras, translations);
  try {
    localStorage.setItem(extrasKey, JSON.stringify({
      version: TRANSLATION_VERSION,
      strings: mergedExtras
    }));
  } catch (e) { /* quota exceeded, ignore */ }

  applyTranslations();
}

async function retryTranslationInBackground(code, langInfo, cacheKey) {
  // Only retry if still on the same language
  if (getCurrentLang() !== code) return;
  try {
    var result = await apiFetch('/api/translate', {
      method: 'POST',
      body: JSON.stringify({
        type: 'ui',
        targetLanguage: langInfo.englishName,
        strings: sourceStrings
      })
    });
    if (result.translations) {
      currentTranslations = result.translations;
      localStorage.setItem(cacheKey, JSON.stringify({
        version: TRANSLATION_VERSION,
        strings: currentTranslations
      }));
      applyTranslations();
      // Also refresh items if on shop page
      if (typeof reloadTranslatedItems === 'function') {
        reloadTranslatedItems();
      }
    }
  } catch (e) {
    console.log('Background translation retry failed:', e);
  }
}

// === Item Description Translation ===
// Uses the SAME flat key-value translation pattern as UI strings (Sacred Verse approach).
// Items are flattened to {"desc_0": "...", "reason_0": "..."} and sent through the
// same /api/translate endpoint. localStorage cache with source-text validation.

async function translateItems(items, targetLangCode) {
  if (!items || items.length === 0) return items;
  if (!targetLangCode) targetLangCode = getCurrentLang();

  // Items are stored in Spanish — no translation needed for Spanish
  if (targetLangCode === 'es') return items;

  var langInfo = getLanguageInfo(targetLangCode);

  // Load persistent cache for this language
  var cacheKey = 'item_translations_' + targetLangCode;
  var cache = {};
  try { cache = JSON.parse(localStorage.getItem(cacheKey) || '{}'); } catch (e) {}

  // Signature combining every translatable field so a change in any of them
  // re-triggers translation.
  function itemSrcSig(item) {
    return (item.description || '') + '|' + (item.ai_reasoning || '') + '|' + (item.brand || '');
  }

  var needsTranslation = items.filter(function(item) {
    var cached = cache[item.id];
    return !(cached && cached.description && cached.srcSig === itemSrcSig(item));
  });

  if (needsTranslation.length > 0) {
    // Build flat key-value object — same format Sacred Verse uses for UI strings
    var strings = {};
    var idList = [];
    needsTranslation.forEach(function(item, idx) {
      idList.push(item.id);
      strings['desc_' + idx] = item.description || '';
      if (item.ai_reasoning) {
        strings['reason_' + idx] = item.ai_reasoning;
      }
      if (item.brand) {
        strings['brand_' + idx] = item.brand;
      }
    });

    console.log('[translateItems] Translating', idList.length, 'items to', langInfo.englishName);
    var translations = await translateApi(langInfo.englishName, 'items', strings);
    if (translations) {
      console.log('[translateItems] API response keys:', Object.keys(translations).length);
      idList.forEach(function(itemId, idx) {
        var desc = translations['desc_' + idx];
        var reason = translations['reason_' + idx];
        var brand = translations['brand_' + idx];
        if (desc && desc.trim()) {
          var srcItem = needsTranslation[idx];
          cache[itemId] = {
            description: desc,
            ai_reasoning: reason || '',
            brand: brand || '',
            srcSig: itemSrcSig(srcItem)
          };
        }
      });
      try { localStorage.setItem(cacheKey, JSON.stringify(cache)); } catch (e) {}
    }
  }

  // Return items with translations applied
  return items.map(function(item) {
    var translated = cache[item.id];
    if (translated && translated.description && translated.description.trim()) {
      return Object.assign({}, item, {
        description: translated.description,
        ai_reasoning: translated.ai_reasoning || item.ai_reasoning,
        brand: translated.brand || item.brand
      });
    }
    return item;
  });
}

// === Event / Workshop Translation ===
// Same flat key-value pattern as translateItems. Translates user-authored
// free-text fields; leaves contact, URLs, dates, prices, ids untouched.

var EVENT_TRANSLATABLE_FIELDS = ['title', 'description', 'location', 'organizer', 'requirements'];

async function translateEvents(events, targetLangCode) {
  if (!events || events.length === 0) return events;
  if (!targetLangCode) targetLangCode = getCurrentLang();

  // Events are stored in Spanish — no translation needed for Spanish
  if (targetLangCode === 'es') return events;

  var langInfo = getLanguageInfo(targetLangCode);
  var cacheKey = 'event_translations_' + targetLangCode;
  var cache = {};
  try { cache = JSON.parse(localStorage.getItem(cacheKey) || '{}'); } catch (e) {}

  // Source-text signature: re-translate whenever any translatable field changes
  function srcSig(ev) {
    return EVENT_TRANSLATABLE_FIELDS.map(function(f) { return ev[f] || ''; }).join('');
  }

  // Which translatable fields does this event actually have source text for?
  function expectedFields(ev) {
    return EVENT_TRANSLATABLE_FIELDS.filter(function(f) {
      return ev[f] && String(ev[f]).trim();
    });
  }

  // Cache entry is "complete" only if every source field got a translation.
  // Prevents a partial translation (e.g. title returned but location dropped)
  // from sticking in localStorage and never re-translating on next load.
  function cacheComplete(entry, ev) {
    if (!entry || entry.srcSig !== srcSig(ev)) return false;
    return expectedFields(ev).every(function(f) {
      return entry[f] && String(entry[f]).trim();
    });
  }

  var needsTranslation = events.filter(function(ev) {
    return !cacheComplete(cache[ev.id], ev);
  });

  if (needsTranslation.length > 0) {
    var strings = {};
    var idList = [];
    needsTranslation.forEach(function(ev, idx) {
      idList.push(ev.id);
      EVENT_TRANSLATABLE_FIELDS.forEach(function(field) {
        if (ev[field] && String(ev[field]).trim()) {
          strings[field + '_' + idx] = String(ev[field]);
        }
      });
    });

    if (Object.keys(strings).length > 0) {
      var translations = await translateApi(langInfo.englishName, 'items', strings);
      if (translations) {
        idList.forEach(function(eventId, idx) {
          var srcEvent = needsTranslation[idx];
          var entry = { srcSig: srcSig(srcEvent) };
          EVENT_TRANSLATABLE_FIELDS.forEach(function(field) {
            var value = translations[field + '_' + idx];
            if (value && String(value).trim()) entry[field] = value;
          });
          // Only persist complete entries — incomplete ones (missing fields)
          // will be retried on the next page load instead of permanently
          // showing raw text.
          if (cacheComplete(entry, srcEvent)) {
            cache[eventId] = entry;
          }
        });
        try { localStorage.setItem(cacheKey, JSON.stringify(cache)); } catch (e) {}
      }
    }
  }

  return events.map(function(ev) {
    var translated = cache[ev.id];
    if (!translated) return ev;
    var merged = Object.assign({}, ev);
    EVENT_TRANSLATABLE_FIELDS.forEach(function(field) {
      if (translated[field]) merged[field] = translated[field];
    });
    return merged;
  });
}

// === Arbitrary Label Translation ===
// Translates a list of plain source-text labels (custom category names,
// group/sub labels, etc.) using the same /api/translate endpoint.
// Returns a { sourceText: translatedText } map, persisted in localStorage.

async function translateLabels(labels, targetLangCode) {
  var out = {};
  if (!labels || labels.length === 0) return out;
  if (!targetLangCode) targetLangCode = getCurrentLang();

  var unique = [];
  var seen = {};
  labels.forEach(function(l) {
    if (l && !seen[l]) { seen[l] = 1; unique.push(String(l)); }
  });
  if (unique.length === 0) return out;

  if (targetLangCode === 'es') {
    unique.forEach(function(l) { out[l] = l; });
    return out;
  }

  var langInfo = getLanguageInfo(targetLangCode);
  var cacheKey = 'label_translations_' + targetLangCode;
  var cache = {};
  try { cache = JSON.parse(localStorage.getItem(cacheKey) || '{}'); } catch (e) {}

  var missing = unique.filter(function(l) { return !cache[l]; });
  if (missing.length > 0) {
    var strings = {};
    missing.forEach(function(l, idx) { strings['lbl_' + idx] = l; });
    var translations = await translateApi(langInfo.englishName, 'ui', strings);
    if (translations) {
      missing.forEach(function(l, idx) {
        var v = translations['lbl_' + idx];
        if (v && String(v).trim()) cache[l] = v;
      });
      try { localStorage.setItem(cacheKey, JSON.stringify(cache)); } catch (e) {}
    }
  }

  unique.forEach(function(l) { out[l] = cache[l] || l; });
  return out;
}

// === DOM Updates ===

function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    const translated = t(key);
    if (translated && translated !== key) {
      el.textContent = translated;
    }
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    const translated = t(key);
    if (translated && translated !== key) {
      el.placeholder = translated;
    }
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    const key = el.getAttribute('data-i18n-title');
    const translated = t(key);
    if (translated && translated !== key) {
      el.title = translated;
    }
  });

  // Update page title dynamically
  var pageTitleKey = document.documentElement.getAttribute('data-i18n-page-title');
  if (pageTitleKey) {
    var translatedTitle = t(pageTitleKey);
    if (translatedTitle && translatedTitle !== pageTitleKey) {
      document.title = translatedTitle;
    }
  }
}

async function setLang(code) {
  localStorage.setItem('lang', code);
  document.documentElement.lang = code;
  // Set RTL for Arabic
  document.documentElement.dir = (code === 'ar') ? 'rtl' : 'ltr';
  await loadTranslations(code);
  applyTranslations();
}

async function initLanguage() {
  const code = getCurrentLang();
  document.documentElement.lang = code;
  document.documentElement.dir = (code === 'ar') ? 'rtl' : 'ltr';
  await loadTranslations(code);
  applyTranslations();
  buildLangSelector();
  // Signal that translations are loaded — reveals hidden content
  document.body.classList.add('i18n-ready');
}

// === Language Selector (flagcdn images) ===

function buildLangSelector() {
  const container = document.getElementById('langSelector');
  if (!container) return;

  const current = getCurrentLang();
  const currentLang = getLanguageInfo(current);
  container.innerHTML = '';

  // Backdrop for closing
  const backdrop = document.createElement('div');
  backdrop.className = 'lang-backdrop';
  container.appendChild(backdrop);

  // Flag bubble button (image background)
  const bubble = document.createElement('button');
  bubble.className = 'lang-bubble';
  bubble.id = 'langBubble';
  bubble.style.backgroundImage = 'url(https://flagcdn.com/w80/' + currentLang.countryCode + '.png)';
  bubble.title = currentLang.name;
  bubble.setAttribute('aria-label', 'Select language');
  bubble.setAttribute('aria-haspopup', 'true');
  container.appendChild(bubble);

  // Dropdown
  const dropdown = document.createElement('div');
  dropdown.className = 'lang-dropdown';
  dropdown.id = 'langDropdown';

  allLanguages.forEach(function(lang) {
    if (lang.code === 'divider') {
      var divider = document.createElement('div');
      divider.className = 'lang-dropdown-divider';
      dropdown.appendChild(divider);
      return;
    }

    var item = document.createElement('button');
    item.className = 'lang-dropdown-item' + (lang.code === current ? ' active' : '');
    item.innerHTML =
      '<img class="lang-dropdown-item-flag" src="https://flagcdn.com/w40/' + lang.countryCode + '.png" alt="" width="28" onerror="this.style.display=\'none\'">' +
      '<span class="lang-dropdown-item-name">' + lang.name + '</span>';

    item.addEventListener('click', async function() {
      dropdown.classList.remove('open');
      backdrop.classList.remove('open');
      await setLang(lang.code);
      // Update bubble
      bubble.style.backgroundImage = 'url(https://flagcdn.com/w80/' + lang.countryCode + '.png)';
      bubble.title = lang.name;
      dropdown.querySelectorAll('.lang-dropdown-item').forEach(function(i) { i.classList.remove('active'); });
      item.classList.add('active');
      // Reload item descriptions if on shop/volunteer page
      if (typeof reloadTranslatedItems === 'function') {
        try {
          await reloadTranslatedItems();
        } catch (e) {
          console.warn('Item translation reload failed:', e);
        }
      }
    });
    dropdown.appendChild(item);
  });

  container.appendChild(dropdown);

  // Toggle dropdown
  bubble.addEventListener('click', function(e) {
    e.stopPropagation();
    var isOpen = dropdown.classList.contains('open');
    dropdown.classList.toggle('open', !isOpen);
    backdrop.classList.toggle('open', !isOpen);
  });

  backdrop.addEventListener('click', function() {
    dropdown.classList.remove('open');
    backdrop.classList.remove('open');
  });
}

// === Translation Overlay ===

function showTranslationOverlay() {
  var overlay = document.getElementById('translationOverlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'translationOverlay';
    overlay.className = 'translation-overlay';
    overlay.innerHTML = '<div class="translation-overlay-content">' +
      '<div class="translation-overlay-spinner"></div>' +
      '<div class="translation-overlay-text">' + (currentTranslations ? t('translating') : 'Translating...') + '</div>' +
      '</div>';
    document.body.appendChild(overlay);
  }
  overlay.style.display = 'flex';
}

function hideTranslationOverlay() {
  var overlay = document.getElementById('translationOverlay');
  if (overlay) {
    overlay.style.display = 'none';
  }
}

// === Service Overload Modal ===

function showServiceOverloadModal() {
  // Non-blocking toast notification instead of blocking modal
  var existing = document.getElementById('serviceOverloadToast');
  if (existing) { existing.remove(); }

  var toast = document.createElement('div');
  toast.id = 'serviceOverloadToast';
  toast.className = 'service-overload-toast';
  toast.innerHTML =
    '<span>' + t('serviceOverloadMsg') + '</span>' +
    '<button class="service-overload-toast-close">&times;</button>';
  document.body.appendChild(toast);

  // Auto-dismiss after 8 seconds (longer message needs more reading time)
  var timeout = setTimeout(function() { toast.remove(); }, 8000);

  toast.querySelector('.service-overload-toast-close').addEventListener('click', function() {
    clearTimeout(timeout);
    toast.remove();
  });
}
