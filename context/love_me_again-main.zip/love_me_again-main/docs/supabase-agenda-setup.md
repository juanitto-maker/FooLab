# Supabase setup — Workshops & Events

Run these two steps **once** in your Supabase project. All existing `items`,
`config`, and `badges` data is untouched.

## 1. Create the `events` table (SQL Editor → New query → paste → Run)

```sql
create table if not exists public.events (
  id            uuid primary key default gen_random_uuid(),
  kind          text not null check (kind in ('workshop','event')),
  title         text not null,
  description   text,
  starts_at     timestamptz not null,
  ends_at       timestamptz,
  location      text,
  capacity      int,
  price_eur     decimal(10,2),
  organizer     text,
  contact       text,
  requirements  text,
  language      text default 'es',
  status        text not null default 'published'
                check (status in ('draft','published','cancelled')),
  photo_urls    text[] not null default '{}',
  video_url     text,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

create index if not exists events_kind_starts_at_idx
  on public.events (kind, starts_at);

-- RLS: public can read published rows, writes go through the service key
alter table public.events enable row level security;

drop policy if exists "events_public_read" on public.events;
create policy "events_public_read"
  on public.events for select
  using (status = 'published');
```

The API routes (`/api/event`, `/api/events`) use the service key, so they bypass
RLS automatically — they don't need a write policy.

## 2. Create the storage bucket for posters

**Storage → Create bucket**
- Name: `event-photos`
- Public bucket: **ON** (so the shop's public pages can display the images)
- File size limit: leave default (or raise to 10 MB if you expect very large posters)

Then apply the same public-read / service-key-write policies:

```sql
-- Allow anyone to read objects from event-photos
create policy "event_photos_public_read"
  on storage.objects for select
  using (bucket_id = 'event-photos');
```

The service key can already write — no extra policy needed.

## 3. No new environment variables

All the existing Vercel secrets (`SUPABASE_URL`, `SUPABASE_SERVICE_KEY`, etc.)
are reused. No new keys to add.

## 4. Verify

After deploy you should be able to:
- `GET https://<your-app>/api/events?kind=workshop&when=upcoming` → returns `{events:[], total:0}`
- Visit `/workshops` and `/events` — empty states render
- From `/volunteer`, open "Gestionar talleres y eventos", fill the form,
  upload a poster, save — then see it appear on the public page.

## 5. Optional — pre-fill location from shop address

The volunteer form leaves `location` blank by default. If you want the shop's
address auto-suggested, add a default in the browser via the `config` table
(no code change needed — volunteers can just type it in).
