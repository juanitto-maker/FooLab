# Love Me Again

AI-powered pricing & inventory system for solidarity shops (tiendas solidarias). Free, multilingual, zero-cost to operate.

## What It Does

1. **Volunteer takes a photo** of a donated item
2. **AI identifies it** (brand, model, category, condition) and suggests a fair price
3. **Volunteer confirms or adjusts** the price — the item appears on the public shop webpage
4. **Customers browse online** to see what's available before visiting
5. **AI learns** from the shop's pricing decisions over time

## Architecture

```
┌─────────────────────────────────────────────────┐
│            love-me-again.vercel.app              │
│                                                  │
│  Public Routes          Volunteer Routes (PIN)   │
│  /           landing    /volunteer       PIN     │
│  /shop       browse     /volunteer/price camera  │
│  /shop/:id   detail     /volunteer/items manage  │
└──────────────┬──────────────────┬────────────────┘
               │                  │
        ┌──────▼──────────────────▼──────┐
        │     Vercel Serverless API      │
        │                                │
        │  /api/analyze   → Gemini AI    │
        │  /api/item      → Supabase     │
        │  /api/items     → Supabase     │
        └──────┬──────────────┬──────────┘
               │              │
        ┌──────▼──────┐ ┌────▼──────────┐
        │ Gemini 2.5  │ │   Supabase    │
        │   Flash     │ │  PostgreSQL   │
        │  (vision)   │ │  + Storage    │
        └─────────────┘ └───────────────┘
```

## Tech Stack (100% Free Tier)

| Service | Purpose | Free Tier |
|---------|---------|-----------|
| **Vercel** | Hosting + serverless functions | 100K invocations/month |
| **Supabase** | PostgreSQL + image storage | 500 MB DB + 1 GB storage |
| **Gemini 2.5 Flash** | Vision AI for item recognition + pricing | 500 requests/day |

**Total cost: €0**

## Features

### Volunteer App (`/volunteer`)
- Camera capture or photo upload
- Multi-object detection (AI asks which item to price if photo has several)
- AI-powered price suggestion with confidence level and reasoning
- Accept suggested price or enter actual selling price
- Mark items as sold with final negotiated price
- Today's pricing history view

### Public Shop Page (`/shop`)
- Browse all available items with photos and prices
- Filter by category (clothes, electronics, furniture, books, toys, etc.)
- Individual item detail pages
- Recently sold items section
- Shop info (name, location, hours, contact)
- Future: item reservation, delivery requests

### Multilingual (AI-Powered)
- Static UI: Spanish, English, German, Italian (hardcoded)
- Dynamic content (descriptions, reasoning): Gemini translates on the fly
- Adding new languages: just add to the dropdown — AI handles the rest

### AI Price Learning
- Every pricing decision is stored
- Recent same-category pricing history is fed back to Gemini
- AI adapts to the shop's specific pricing style over time

## Database Schema

### `items` table
| Column | Type | Description |
|--------|------|-------------|
| id | uuid | Primary key |
| photo_url | text | Supabase Storage URL |
| description | text | AI-generated item description |
| category | text | clothes, electronics, furniture, books, toys, other |
| brand | text | Brand/model if identified |
| condition | text | AI-estimated: like_new, good, fair, worn |
| ai_suggested_price | decimal | AI's recommended price (€) |
| final_price | decimal | Actual selling price set by volunteer |
| status | text | available, reserved, sold |
| language | text | Language used during pricing (es, en, de, it) |
| ai_reasoning | text | AI's pricing rationale |
| ai_confidence | text | high, medium, low |
| created_at | timestamptz | When item was added |
| sold_at | timestamptz | When item was marked sold |

### `config` table
| Column | Type | Description |
|--------|------|-------------|
| key | text | Config key (e.g., 'volunteer_pin', 'shop_name') |
| value | text | Config value |

## Project Structure

```
love-me-again/
├── api/
│   ├── analyze.js          # Gemini vision + pricing endpoint
│   ├── item.js             # Create/update items endpoint
│   └── items.js            # Read inventory endpoint
├── public/
│   ├── index.html          # Landing page
│   ├── shop.html           # Public inventory browser
│   ├── volunteer.html      # Volunteer pricing tool
│   ├── manifest.json       # PWA manifest
│   ├── sw.js               # Service worker
│   ├── css/
│   │   └── styles.css      # Shared styles
│   ├── js/
│   │   ├── app.js          # Shared app logic
│   │   ├── i18n.js         # Translations + language selector
│   │   ├── shop.js         # Public page logic
│   │   ├── volunteer.js    # Volunteer tool logic
│   │   └── supabase.js     # Supabase client config
│   └── icons/
│       ├── icon-192.png
│       └── icon-512.png
├── vercel.json             # Vercel routing config
├── package.json
├── CLAUDE.md               # Claude Code instructions
└── README.md               # This file
```

## Environment Variables (Vercel Secrets)

| Variable | Description |
|----------|-------------|
| `GEMINI_API_KEY` | Google AI Studio API key |
| `SUPABASE_URL` | Supabase project URL |
| `SUPABASE_ANON_KEY` | Supabase anonymous/public key |
| `SUPABASE_SERVICE_KEY` | Supabase service role key (for server-side operations) |
| `PUBLIC_APP_URL` | Production URL (e.g., `https://love-me-again.vercel.app`) |

**NEVER commit API keys to the repository. All keys go in Vercel dashboard → Settings → Environment Variables.**

## Setup Guide (One-Time)

### Shop Setup
1. Create a Gmail account for the shop
2. Go to [aistudio.google.com](https://aistudio.google.com) → Get API key
3. Go to [supabase.com](https://supabase.com) → Create account + new project
4. Share both keys with the developer

### Developer Setup
1. Clone this repo
2. Connect to Vercel (`vercel link`)
3. Add environment variables in Vercel dashboard
4. Run the Supabase SQL migration (see `/supabase/schema.sql`)
5. Deploy (`vercel --prod`)

### Volunteer Setup
1. Open `love-me-again.vercel.app/volunteer` on phone
2. Enter the shop PIN (provided by manager)
3. Optional: tap "Install" / "Add to Home Screen" for quick access

## Build Order

1. ✅ Set up GitHub repo + connect to Vercel
2. Set up Supabase project — items table + storage bucket
3. Create `/api/analyze` — Gemini vision + pricing
4. Create `/api/item` — save/update items + photo upload
5. Create `/api/items` — read inventory with filters
6. Add secrets to Vercel
7. Build volunteer PWA — camera, pricing, confirm flow
8. Build public shop page — inventory browsing
9. Add multilingual system
10. Add PWA manifest + service worker
11. End-to-end testing

## Limitations & Notes

- Gemini prices are estimates from training knowledge, not live marketplace scraping
- 500 Gemini requests/day is the ceiling (plenty for most shops)
- Supabase free tier pauses after 7 days inactivity (daily use prevents this)
- 1 GB photo storage ≈ 2,000–4,000 compressed photos
- Very niche/local items may get inaccurate estimates — manual adjustment covers this

## License

MIT — Free for solidarity shops and non-profit use.
