# CLAUDE.md — Love Me Again Development Instructions

## Project Overview

Love Me Again is a free AI-powered pricing and inventory system for solidarity shops (tiendas solidarias). It's a single PWA deployed on Vercel with two modes: a public shop browser and a PIN-protected volunteer pricing tool. It uses Gemini 2.5 Flash for vision-based item recognition and pricing, and Supabase for database + image storage.

## Critical Rules

### API Keys & Security
- **NEVER** put API keys in code, `.env` files, or any file committed to the repo
- All keys go in **Vercel dashboard → Settings → Environment Variables** only
- Server-side API routes (`/api/*`) handle all external API calls — the frontend NEVER calls Gemini or Supabase service key directly
- The Supabase anon key is used client-side ONLY for reading public data (shop items)
- Follow the Referer header pattern: always set `Referer: process.env.PUBLIC_APP_URL` on API calls

### Environment Variables (Vercel Secrets)
```
GEMINI_API_KEY          — Google AI Studio key
SUPABASE_URL            — Supabase project URL
SUPABASE_ANON_KEY       — Supabase anonymous key (safe for client)
SUPABASE_SERVICE_KEY    — Supabase service role key (server-side only)
PUBLIC_APP_URL          — Production URL (https://love-me-again.vercel.app)
```

### Model
- Always use **Gemini 2.5 Flash** (`gemini-2.5-flash`) — this is the default model
- API endpoint: `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent`
- Never use other models unless explicitly requested

## Architecture

### Single App, Two Modes
```
love-me-again.vercel.app/           → Public landing page
love-me-again.vercel.app/shop       → Public inventory browser
love-me-again.vercel.app/shop/:id   → Item detail page
love-me-again.vercel.app/volunteer  → PIN entry → Volunteer pricing tool
```

### Serverless API Endpoints (Vercel Functions)
All in `/api/` directory:

**`/api/analyze`** (POST)
- Receives: `{ image: base64string, language: "es"|"en"|"de"|"it" }`
- Sends image to Gemini 2.5 Flash with pricing prompt
- Includes recent same-category pricing history from Supabase for AI learning
- Returns: `{ items: [...], singleItem: bool }` for multi-object detection
- Or for single item: `{ itemName, brand, category, condition, estimatedMarketPrice, recommendedShopPrice, confidence, reasoning }`

**`/api/item`** (POST / PATCH)
- POST: Create new item — receives item data + photo file, uploads photo to Supabase Storage, creates row in items table
- PATCH: Update item — mark as sold, adjust price, update status

**`/api/items`** (GET)
- Query params: `?status=available&category=clothes&limit=20&offset=0`
- Returns items list with photo URLs for the public shop page
- Supports pagination

### Database (Supabase PostgreSQL)

**`items` table:**
```sql
id              uuid DEFAULT gen_random_uuid() PRIMARY KEY
photo_url       text NOT NULL
description     text NOT NULL
category        text NOT NULL  -- clothes, electronics, furniture, books, toys, other
brand           text
condition       text           -- like_new, good, fair, worn
ai_suggested_price  decimal(10,2)
final_price     decimal(10,2)
status          text DEFAULT 'available'  -- available, reserved, sold
language        text DEFAULT 'es'
ai_reasoning    text
ai_confidence   text           -- high, medium, low
created_at      timestamptz DEFAULT now()
sold_at         timestamptz
sold_price      decimal(10,2)  -- actual negotiated selling price
```

**`config` table:**
```sql
key    text PRIMARY KEY
value  text NOT NULL
```
Config rows: `volunteer_pin`, `shop_name`, `shop_address`, `shop_hours`, `shop_phone`

**Supabase Storage bucket:** `item-photos` (public read, authenticated write)

### Photo Handling
- Compress images client-side before upload (max 800px wide, JPEG quality 0.7)
- Upload via the `/api/item` endpoint (which uses SUPABASE_SERVICE_KEY server-side)
- Store the resulting public URL in the `photo_url` column
- Target ~100-200 KB per photo to maximize the 1 GB free storage

## Frontend Guidelines

### Tech Stack
- Vanilla HTML/CSS/JS — no frameworks, no build step
- Single CSS file shared across all pages
- Supabase JS client loaded via CDN for client-side reads only
- Mobile-first responsive design

### File Structure
```
public/
├── index.html          # Landing page (shop info, links to /shop and /volunteer)
├── shop.html           # Public inventory browser
├── volunteer.html      # Volunteer tool (PIN + camera + pricing)
├── manifest.json       # PWA manifest
├── sw.js               # Service worker for offline support
├── css/
│   └── styles.css      # All styles — mobile-first, clean, accessible
├── js/
│   ├── app.js          # Shared utilities (language, fetch helpers)
│   ├── i18n.js         # Translation strings + language switching logic
│   ├── shop.js         # Shop page: load items, filters, item cards
│   ├── volunteer.js    # Camera, AI pricing flow, item management
│   └── supabase.js     # Supabase client init (anon key, for public reads)
└── icons/
    ├── icon-192.png
    └── icon-512.png
```

### Multilingual System (i18n)
- Static UI strings hardcoded in `i18n.js` as a simple object:
```js
const translations = {
  es: { takePhoto: "Tomar foto", price: "Precio", ... },
  en: { takePhoto: "Take photo", price: "Price", ... },
  de: { takePhoto: "Foto aufnehmen", price: "Preis", ... },
  it: { takePhoto: "Scatta foto", price: "Prezzo", ... }
};
```
- Dynamic content (AI descriptions, reasoning): controlled by sending `language` param to `/api/analyze` — Gemini responds in that language
- Language preference saved to `localStorage`
- Language selector appears on all pages (flag icons or dropdown)

### Volunteer PIN System
- Simple 4-6 digit PIN stored in Supabase `config` table
- Volunteer enters PIN once → saved in `localStorage`
- PIN check: client reads the hashed PIN from config and compares
- No full auth system needed — this is a solidarity shop, not a bank

### UI/UX Principles
- Big touch targets (volunteers use this while handling items)
- Clear visual feedback (loading spinners, success/error states)
- Camera button is the primary action — front and center
- Price card should be scannable at a glance: item name, photo, price — big and bold
- Public shop page should feel like a simple, friendly catalog
- Works offline for browsing cached items (service worker)

## Gemini Prompt Strategy

### Multi-Object Detection Prompt
When analyzing an image, first detect objects:
```
Analyze this image. If there are multiple distinct objects that could be sold separately, list each one briefly. If there is one clear main item, identify it directly.

Respond in JSON:
- If multiple: { "multiple": true, "items": ["Red Nike sneakers", "Blue denim jacket", "Ceramic mug"] }
- If single: { "multiple": false, "item": { ... full pricing response ... } }
```

### Pricing Prompt (for single item)
```
You are a pricing expert for second-hand items in Spain. Analyze this item photo and provide a fair price for a solidarity shop (tienda solidaria).

Consider:
- What this item would typically sell for on Wallapop or Milanuncios
- The item's apparent condition from the photo
- Brand value if identifiable

{PRICING_HISTORY_BLOCK — injected from recent same-category items}

Respond in {LANGUAGE} as JSON:
{
  "itemName": "descriptive name",
  "brand": "brand if visible, otherwise null",
  "category": "clothes|electronics|furniture|books|toys|other",
  "condition": "like_new|good|fair|worn",
  "estimatedMarketPrice": number in euros,
  "recommendedShopPrice": number in euros (40-60% of market price),
  "confidence": "high|medium|low",
  "reasoning": "brief explanation of pricing logic"
}
```

### Pricing History Injection
Pull last 20 same-category items from database and format as:
```
Recent pricing history for this shop (category: {category}):
- Item: "Blue Nike Air Max", AI suggested: €25, Shop sold for: €18
- Item: "Red Zara jacket", AI suggested: €15, Shop sold for: €12
...
Based on this shop's pattern, adjust your recommendation accordingly.
```

## Vercel Configuration

### `vercel.json`
```json
{
  "rewrites": [
    { "source": "/shop/:id", "destination": "/shop.html" },
    { "source": "/shop", "destination": "/shop.html" },
    { "source": "/volunteer", "destination": "/volunteer.html" },
    { "source": "/volunteer/:path*", "destination": "/volunteer.html" }
  ]
}
```

### API routes
Files in `/api/` are automatically deployed as Vercel serverless functions.
Use Node.js runtime (default). Each file exports a default handler:
```js
export default async function handler(req, res) { ... }
```

## Development Notes

### Developer Context
- Developer works on **Android mobile** — no local terminal
- Development happens via **Claude Code in browser** and **GitHub web interface**
- All changes are committed and deployed via GitHub → Vercel auto-deploy
- Test by visiting the Vercel preview URL after each push

### Deployment Flow
1. Push to GitHub `main` branch
2. Vercel auto-deploys
3. Test at `love-me-again.vercel.app`
4. Preview deployments available for PRs

### Testing Strategy
- Test `/api/analyze` first with sample base64 images
- Test item creation and photo upload via `/api/item`
- Test public page reads via `/api/items`
- Cross-test all 4 languages
- Test on actual phone cameras (different lighting, angles, multiple objects)

## Build Order

Follow this sequence — each step builds on the previous:

1. **GitHub repo + Vercel connection** — empty project, verify deployment works
2. **Supabase setup** — run schema SQL, create storage bucket, set RLS policies
3. **`/api/analyze`** — Gemini integration, test with sample images
4. **`/api/item`** — create/update items, photo upload to Supabase Storage
5. **`/api/items`** — read inventory with filters and pagination
6. **Vercel secrets** — add all env vars
7. **Volunteer PWA** — camera UI, pricing flow, accept/adjust, mark sold
8. **Public shop page** — item grid, category filters, item detail view
9. **Multilingual** — language selector, i18n.js translations, language param to API
10. **PWA manifest + service worker** — installable, offline browsing
11. **End-to-end testing** — real items, all languages, edge cases
