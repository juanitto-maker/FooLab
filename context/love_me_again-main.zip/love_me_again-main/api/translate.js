const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { type, targetLanguage, strings } = req.body;

  if (!targetLanguage) {
    return res.status(400).json({ error: 'targetLanguage is required' });
  }

  // Both 'ui' and 'items' use the SAME translation approach:
  // flat key-value JSON object in → flat key-value JSON object out.
  // This matches the Sacred Verse pattern exactly.

  if (!strings || typeof strings !== 'object') {
    return res.status(400).json({ error: 'strings object is required' });
  }

  try {
    const prompt = 'Translate the JSON values from their current language to ' + targetLanguage + '. ' +
      'Maintain the JSON structure and keys exactly. Only translate the string values. ' +
      'Brand names (Nike, Zara, IKEA, Puma, etc.) must stay unchanged. ' +
      'Return ONLY a valid JSON object, no markdown, no code fences, no explanation.\n\n' +
      JSON.stringify(strings, null, 2);

    const response = await callGemini(prompt);
    const translations = JSON.parse(cleanJson(response));

    return res.status(200).json({ translations });
  } catch (error) {
    console.error('Translation error:', error.message || error);

    const msg = error.message || '';
    if (msg.includes('429') || msg.includes('quota') || msg.includes('resource_exhausted') || msg.includes('rate')) {
      return res.status(429).json({ error: 'Translation service temporarily unavailable. Please try again later.' });
    }
    if (msg.includes('timed out') || msg.includes('timeout') || msg.includes('AbortError')) {
      return res.status(504).json({ error: 'Translation timed out. Please try again.' });
    }

    return res.status(500).json({ error: 'Translation failed: ' + (msg || 'unknown error') });
  }
}

async function callGemini(prompt) {
  const body = {
    contents: [{
      parts: [{ text: prompt }]
    }]
  };

  const maxRetries = 3;
  let lastError;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(GEMINI_URL + '?key=' + process.env.GEMINI_API_KEY, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Referer': process.env.PUBLIC_APP_URL || 'https://love-me-again.vercel.app'
        },
        body: JSON.stringify(body)
      });

      const data = await response.json();

      if (!response.ok) {
        const err = new Error('Gemini API error ' + response.status + ': ' + JSON.stringify(data));
        err.status = response.status;
        // Retry on 429 (rate limit), 503 (overloaded), 500 (internal) with backoff
        if ((response.status === 429 || response.status === 503 || response.status === 500) && attempt < maxRetries) {
          const delay = (attempt + 1) * 1500;
          console.log(`Gemini translate ${response.status} (attempt ${attempt + 1}), retrying in ${delay}ms`);
          await new Promise(r => setTimeout(r, delay));
          lastError = err;
          continue;
        }
        throw err;
      }

      if (!data.candidates || !data.candidates[0]?.content?.parts) {
        throw new Error('Gemini returned no content');
      }

      const parts = data.candidates[0].content.parts;
      const textParts = parts.filter(p => p.text);
      return textParts.map(p => p.text).join('');
    } catch (fetchErr) {
      lastError = fetchErr;
      if (fetchErr.status) throw fetchErr; // Gemini non-retryable error — bubble up
      if (attempt < maxRetries) {
        const delay = (attempt + 1) * 1500;
        console.log(`Gemini translate fetch failed (attempt ${attempt + 1}), retrying in ${delay}ms`);
        await new Promise(r => setTimeout(r, delay));
        continue;
      }
    }
  }

  throw lastError || new Error('Gemini translate failed after retries');
}

function cleanJson(text) {
  return text.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
}
