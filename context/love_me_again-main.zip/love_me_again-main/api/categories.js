import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const DEFAULT_CATEGORIES = [
  { id: 'clothes', name: { es: 'Ropa', en: 'Clothes', de: 'Kleidung', it: 'Abbigliamento' } },
  { id: 'electronics', name: { es: 'Electrónica', en: 'Electronics', de: 'Elektronik', it: 'Elettronica' } },
  { id: 'furniture', name: { es: 'Muebles', en: 'Furniture', de: 'Möbel', it: 'Mobili' } },
  { id: 'books', name: { es: 'Libros', en: 'Books', de: 'Bücher', it: 'Libri' } },
  { id: 'toys', name: { es: 'Juguetes', en: 'Toys', de: 'Spielzeug', it: 'Giocattoli' } },
  { id: 'other', name: { es: 'Otros', en: 'Other', de: 'Sonstiges', it: 'Altro' } }
];

async function getCategories() {
  const { data } = await supabase
    .from('config')
    .select('value')
    .eq('key', 'categories')
    .single();

  if (data && data.value) {
    try {
      return JSON.parse(data.value);
    } catch (e) {
      return DEFAULT_CATEGORIES;
    }
  }
  return DEFAULT_CATEGORIES;
}

async function saveCategories(categories) {
  const { error } = await supabase
    .from('config')
    .upsert({ key: 'categories', value: JSON.stringify(categories) });

  if (error) throw error;
}

function slugify(str) {
  return str.toLowerCase().trim().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
}

export default async function handler(req, res) {
  // GET — list all categories
  if (req.method === 'GET') {
    try {
      const categories = await getCategories();
      return res.status(200).json({ categories });
    } catch (error) {
      console.error('Get categories error:', error);
      return res.status(500).json({ error: 'Failed to fetch categories' });
    }
  }

  // POST — add a new category (supports subcategories)
  if (req.method === 'POST') {
    try {
      const { category, subcategory, name } = req.body;
      if (!category) {
        return res.status(400).json({ error: 'category is required' });
      }

      const catSlug = slugify(category);
      const subSlug = subcategory ? slugify(subcategory) : '';
      const id = subSlug ? `${catSlug}_${subSlug}` : catSlug;

      const categories = await getCategories();

      if (categories.some(c => c.id === id)) {
        return res.status(409).json({ error: 'Category already exists' });
      }

      const entry = {
        id,
        name: name || {},
        group: catSlug
      };

      // If there's a subcategory, store the group name from the category field
      // and the display name from the subcategory field
      if (subSlug) {
        entry.groupLabel = category.trim();
        entry.subLabel = subcategory.trim();
      }

      categories.push(entry);
      await saveCategories(categories);

      return res.status(201).json({ categories });
    } catch (error) {
      console.error('Add category error:', error);
      return res.status(500).json({ error: 'Failed to add category' });
    }
  }

  // DELETE — remove a category
  if (req.method === 'DELETE') {
    try {
      const { id } = req.body;
      if (!id) {
        return res.status(400).json({ error: 'id is required' });
      }

      const categories = await getCategories();
      const filtered = categories.filter(c => c.id !== id);

      if (filtered.length === categories.length) {
        return res.status(404).json({ error: 'Category not found' });
      }

      await saveCategories(filtered);

      return res.status(200).json({ categories: filtered });
    } catch (error) {
      console.error('Delete category error:', error);
      return res.status(500).json({ error: 'Failed to delete category' });
    }
  }

  return res.status(405).json({ error: 'Method not allowed' });
}
