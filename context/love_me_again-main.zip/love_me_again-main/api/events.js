import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const {
      kind,
      when = 'upcoming',
      limit = '20',
      offset = '0'
    } = req.query;

    let query = supabase
      .from('events')
      .select('*', { count: 'exact' });

    if (kind && kind !== 'all') {
      query = query.eq('kind', kind);
    }

    const nowIso = new Date().toISOString();
    if (when === 'upcoming') {
      query = query
        .or(`ends_at.gte.${nowIso},and(ends_at.is.null,starts_at.gte.${nowIso})`)
        .order('starts_at', { ascending: true });
    } else if (when === 'past') {
      query = query
        .or(`ends_at.lt.${nowIso},and(ends_at.is.null,starts_at.lt.${nowIso})`)
        .order('starts_at', { ascending: false });
    } else {
      query = query.order('starts_at', { ascending: false });
    }

    query = query.range(parseInt(offset), parseInt(offset) + parseInt(limit) - 1);

    const { data, error, count } = await query;

    if (error) {
      console.error('Events query error:', error);
      return res.status(500).json({ error: 'Failed to fetch events' });
    }

    return res.status(200).json({
      events: data || [],
      total: count || 0,
      limit: parseInt(limit),
      offset: parseInt(offset)
    });
  } catch (error) {
    console.error('Events error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
