import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const DEFAULT_BADGES = [
  { color: 'green', emoji: '💚', min: 0, max: 5 },
  { color: 'blue', emoji: '💙', min: 5, max: 10 },
  { color: 'orange', emoji: '🧡', min: 10, max: 20 },
  { color: 'red', emoji: '❤️', min: 20, max: null }
];

async function getBadges() {
  const { data } = await supabase
    .from('config')
    .select('value')
    .eq('key', 'price_badges')
    .single();

  if (data && data.value) {
    try {
      return JSON.parse(data.value);
    } catch (e) {
      return DEFAULT_BADGES;
    }
  }
  return DEFAULT_BADGES;
}

export default async function handler(req, res) {
  if (req.method === 'GET') {
    try {
      const badges = await getBadges();
      return res.status(200).json({ badges });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to load badges' });
    }
  }

  if (req.method === 'PUT') {
    try {
      const { badges } = req.body;
      if (!Array.isArray(badges) || badges.length === 0) {
        return res.status(400).json({ error: 'Invalid badges data' });
      }

      // Validate each badge
      for (const b of badges) {
        if (typeof b.min !== 'number' || (b.max !== null && typeof b.max !== 'number')) {
          return res.status(400).json({ error: 'Invalid badge range' });
        }
        if (b.max !== null && b.max <= b.min) {
          return res.status(400).json({ error: 'Max must be greater than min' });
        }
      }

      const { error } = await supabase
        .from('config')
        .upsert({ key: 'price_badges', value: JSON.stringify(badges) }, { onConflict: 'key' });

      if (error) throw error;

      return res.status(200).json({ badges });
    } catch (err) {
      return res.status(500).json({ error: 'Failed to save badges' });
    }
  }

  res.setHeader('Allow', 'GET, PUT');
  return res.status(405).json({ error: 'Method not allowed' });
}
