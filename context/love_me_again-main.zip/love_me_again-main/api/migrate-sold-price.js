import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    // Add sold_price column to items table
    const { error } = await supabase.rpc('exec_sql', {
      query: 'ALTER TABLE items ADD COLUMN IF NOT EXISTS sold_price decimal(10,2);'
    });

    if (error) {
      // Try direct SQL via REST if rpc not available
      const response = await fetch(`${process.env.SUPABASE_URL}/rest/v1/rpc/exec_sql`, {
        method: 'POST',
        headers: {
          'apikey': process.env.SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          query: 'ALTER TABLE items ADD COLUMN IF NOT EXISTS sold_price decimal(10,2);'
        })
      });

      if (!response.ok) {
        return res.status(200).json({
          warning: 'Could not auto-migrate. Please run this SQL in Supabase dashboard:',
          sql: 'ALTER TABLE items ADD COLUMN IF NOT EXISTS sold_price decimal(10,2);'
        });
      }
    }

    return res.status(200).json({ success: true, message: 'sold_price column added' });
  } catch (error) {
    return res.status(200).json({
      warning: 'Could not auto-migrate. Please run this SQL in Supabase SQL Editor:',
      sql: 'ALTER TABLE items ADD COLUMN IF NOT EXISTS sold_price decimal(10,2);'
    });
  }
}
