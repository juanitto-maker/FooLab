import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const MIGRATION_SQL = 'ALTER TABLE items ADD COLUMN IF NOT EXISTS photo_urls text[];';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { error } = await supabase.rpc('exec_sql', { query: MIGRATION_SQL });

    if (error) {
      const response = await fetch(`${process.env.SUPABASE_URL}/rest/v1/rpc/exec_sql`, {
        method: 'POST',
        headers: {
          'apikey': process.env.SUPABASE_SERVICE_KEY,
          'Authorization': `Bearer ${process.env.SUPABASE_SERVICE_KEY}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ query: MIGRATION_SQL })
      });

      if (!response.ok) {
        return res.status(200).json({
          warning: 'Could not auto-migrate. Please run this SQL in Supabase SQL Editor:',
          sql: MIGRATION_SQL
        });
      }
    }

    return res.status(200).json({ success: true, message: 'photo_urls column added' });
  } catch (error) {
    return res.status(200).json({
      warning: 'Could not auto-migrate. Please run this SQL in Supabase SQL Editor:',
      sql: MIGRATION_SQL
    });
  }
}
