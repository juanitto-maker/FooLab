import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

const GEMINI_URL = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent';

const DEFAULT_CATEGORIES = ['clothes', 'electronics', 'furniture', 'books', 'toys', 'other'];

async function getCategoryIds() {
  try {
    const { data } = await supabase
      .from('config')
      .select('value')
      .eq('key', 'categories')
      .single();

    if (data && data.value) {
      const categories = JSON.parse(data.value);
      return categories.map(c => c.id);
    }
  } catch (e) {
    // fallback to defaults
  }
  return DEFAULT_CATEGORIES;
}

async function getPricingHistory(category) {
  const { data } = await supabase
    .from('items')
    .select('description, ai_suggested_price, final_price')
    .eq('category', category)
    .order('created_at', { ascending: false })
    .limit(20);

  if (!data || data.length === 0) return '';

  const lines = data.map(item => {
    const sold = item.final_price ? `, Shop sold for: €${item.final_price}` : '';
    return `- Item: "${item.description}", AI suggested: €${item.ai_suggested_price}${sold}`;
  });

  return `\nRecent pricing history for this shop (category: ${category}):\n${lines.join('\n')}\nBased on this shop's pattern, adjust your recommendation accordingly.\n`;
}

// Google Custom Search API — primary price research
async function searchPrices(query) {
  const apiKey = process.env.GOOGLE_SEARCH_API_KEY;
  const cx = process.env.GOOGLE_SEARCH_CX;

  if (!apiKey || !cx) return null;

  try {
    const params = new URLSearchParams({
      key: apiKey,
      cx: cx,
      q: `${query} precio segunda mano españa`,
      num: '5'
    });

    const response = await fetch(`https://www.googleapis.com/customsearch/v1?${params}`);
    const data = await response.json();

    if (!response.ok || !data.items) return null;

    return data.items.map(item => ({
      title: item.title,
      snippet: item.snippet,
      link: item.link
    }));
  } catch (err) {
    console.log('Google Search failed, will use Gemini grounding:', err.message);
    return null;
  }
}

function formatSearchResults(results) {
  if (!results || results.length === 0) return '';

  const lines = results.map(r => `- "${r.title}": ${r.snippet}`);
  return `\nReal price data found online:\n${lines.join('\n')}\nUse these real prices to calibrate your estimate.\n`;
}

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '12mb'
    }
  }
};

const MAX_IMAGES = 5;

function normalizeImages(body) {
  const { image, images } = body;
  if (Array.isArray(images) && images.length > 0) {
    return images.filter(Boolean).slice(0, MAX_IMAGES);
  }
  if (image) return [image];
  return [];
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { language = 'es', materials, userCondition } = req.body;
  const imageList = normalizeImages(req.body);

  if (imageList.length === 0) {
    return res.status(400).json({ error: 'Image is required' });
  }

  try {
    // If user provided materials info, go straight to material-based pricing
    if (materials) {
      return await handleMaterialsPricing(req, res, imageList, language, materials, userCondition);
    }

    // Step 1: Detect if multiple objects
    const multiPhotoNote = imageList.length > 1
      ? `\nIMPORTANT: The ${imageList.length} photos all show the SAME item from different angles. Treat them as one item, not several.`
      : '';

    const detectionPrompt = `Analyze ${imageList.length > 1 ? 'these images' : 'this image'}. If there are multiple distinct objects that could be sold separately, list each one briefly. If there is one clear main item, identify it directly.${multiPhotoNote}

Write all item descriptions in ${getLanguageName(language)}. Keep brand names (Nike, Zara, IKEA, etc.) unchanged.

Respond ONLY with valid JSON (no markdown, no code fences):
- If multiple: { "multiple": true, "items": ["Red Nike sneakers", "Blue denim jacket", "Ceramic mug"] }
- If single: { "multiple": false, "item": "ITEM_DESCRIPTION" }`;

    const detectionResponse = await callGemini(imageList, detectionPrompt, false);
    let detection;
    try {
      detection = JSON.parse(cleanJson(detectionResponse));
    } catch (parseErr) {
      console.error('Detection JSON parse failed. Raw response:', detectionResponse.substring(0, 500));
      throw new Error('AI returned an invalid response. Please try again.');
    }

    if (detection.multiple) {
      return res.status(200).json({
        singleItem: false,
        items: detection.items
      });
    }

    // Step 2: Try Google Custom Search for real prices
    const itemDesc = detection.item || 'the item in the photo';
    const searchResults = await searchPrices(itemDesc);
    const searchBlock = formatSearchResults(searchResults);
    const useGeminiGrounding = !searchResults; // fallback to Gemini grounding if Google Search failed

    const categoryIds = await getCategoryIds();
    const categoryList = categoryIds.join('|');

    const historyBlock = await getPricingHistory('clothes');

    const photoCountNote = imageList.length > 1
      ? `You have ${imageList.length} photos of the SAME item (different angles, labels, details). Use ALL of them together to identify, condition-check, and price the item.`
      : 'Analyze this item photo';

    const pricingPrompt = `You are a pricing expert for second-hand items in Spain. ${photoCountNote} and provide a fair price for a solidarity shop (tienda solidaria).
${searchBlock ? `\n${searchBlock}` : '\nIMPORTANT: Use Google Search to look up real prices for this item or similar items on Wallapop, Milanuncios, Amazon.es.'}

PRICING RULES:
- The recommended shop price must be approximately 30% of the estimated new/market price.
- If you CAN identify the item and estimate its value, set "needsInput" to false and provide full pricing.
- If you CANNOT confidently price it, set "needsInput" to true. In that case:
  - Tell the volunteer what additional photo would help (label, tag, different angle)
  - Identify visible materials so the volunteer can confirm/correct them
  - The materials matter hugely for pricing:
    * Plastic/synthetic clothing → market value €2-5, shop price €0.50-1.50
    * Cotton/wool/linen clothing → market value €5-20, shop price €1.50-5
    * Particle board/laminate furniture → market value €10-30, shop price €3-10
    * Solid wood furniture → market value €30-200+, shop price €10-60+
    * Branded items → research the brand and adjust accordingly

Consider:
- What this item would cost NEW or on Wallapop/Milanuncios second-hand
- The item's apparent condition from the photo
- Brand value if identifiable
- Materials visible in the photo (this is critical for pricing!)
${historyBlock}
Respond in ${getLanguageName(language)} ONLY with valid JSON (no markdown, no code fences):

If you CAN price it confidently:
{
  "needsInput": false,
  "itemName": "descriptive name",
  "brand": "brand if visible, otherwise null",
  "category": "${categoryList}",
  "condition": "like_new|good|fair|worn",
  "materials": ["wood", "fabric", "metal", etc],
  "estimatedMarketPrice": number in euros,
  "recommendedShopPrice": number in euros (approximately 30% of market price),
  "confidence": "high|medium",
  "reasoning": "brief explanation including any prices found online"
}

If you CANNOT price it confidently:
{
  "needsInput": true,
  "itemName": "best guess descriptive name",
  "category": "${categoryList}",
  "condition": "like_new|good|fair|worn",
  "materialsGuesses": ["list of possible materials for this item"],
  "detectedMaterials": ["materials you can actually see in the photo"],
  "needsMorePhotos": true or false,
  "photoHint": "e.g. 'Take a closer photo of the label/tag' or 'Photo from the front side' — what would help you identify it",
  "reasoning": "why you cannot confidently price this item"
}`;

    const pricingResponse = await callGemini(imageList, pricingPrompt, useGeminiGrounding);
    let pricing;
    try {
      pricing = JSON.parse(cleanJson(pricingResponse));
    } catch (parseErr) {
      console.error('Pricing JSON parse failed. Raw response:', pricingResponse.substring(0, 500));
      throw new Error('AI returned an invalid pricing response. Please try again.');
    }

    const hasValidPricing = pricing.estimatedMarketPrice > 0 && pricing.recommendedShopPrice > 0 && pricing.itemName;

    if (pricing.needsInput || !hasValidPricing) {
      return res.status(200).json({
        singleItem: true,
        needsInput: true,
        itemName: pricing.itemName || itemDesc,
        category: pricing.category || 'other',
        condition: pricing.condition || null,
        materialsGuesses: pricing.materialsGuesses || ['wood', 'metal', 'plastic', 'fabric', 'leather', 'glass', 'ceramic', 'other'],
        detectedMaterials: pricing.detectedMaterials || pricing.materials || [],
        needsMorePhotos: pricing.needsMorePhotos || false,
        photoHint: pricing.photoHint || null,
        reasoning: pricing.reasoning || ''
      });
    }

    // Enforce 30% cap
    const marketPrice = pricing.estimatedMarketPrice;
    let shopPrice = pricing.recommendedShopPrice;
    if (marketPrice && shopPrice && shopPrice > marketPrice * 0.35) {
      shopPrice = Math.round(marketPrice * 0.3 * 2) / 2;
    }

    return res.status(200).json({
      singleItem: true,
      needsInput: false,
      ...pricing,
      recommendedShopPrice: shopPrice
    });
  } catch (error) {
    console.error('Analyze error:', error);
    const status = error.status || 500;
    const message = error.message || 'Failed to analyze image';
    // Surface actionable details to the client
    if (status === 429 || message.includes('429') || message.includes('quota') || message.includes('rate') || message.includes('exhausted')) {
      return res.status(429).json({ error: classifyRateLimit(message, error.geminiDetails) });
    }
    if (message.includes('400') || message.includes('invalid')) {
      return res.status(400).json({ error: 'Image could not be processed. Try a smaller or clearer photo.' });
    }
    return res.status(status).json({ error: message });
  }
}

async function handleMaterialsPricing(req, res, imageList, language, materials, userCondition) {
  try {
    const materialsStr = Array.isArray(materials) ? materials.join(', ') : materials;
    const conditionStr = userCondition || 'unknown';

    // Search for similar items with these materials
    const searchResults = await searchPrices(`${materialsStr} ${conditionStr} segunda mano`);
    const searchBlock = formatSearchResults(searchResults);
    const useGeminiGrounding = !searchResults;

    const categoryIds = await getCategoryIds();
    const categoryList = categoryIds.join('|');

    const historyBlock = await getPricingHistory('other');

    const photoNote = imageList.length > 1
      ? `Analyze these ${imageList.length} photos of the SAME item`
      : 'Analyze this item photo';

    const prompt = `You are a pricing expert for second-hand items in Spain. ${photoNote} for a solidarity shop (tienda solidaria).

The volunteer has identified these details:
- Materials: ${materialsStr}
- Condition: ${conditionStr}
${searchBlock ? `\n${searchBlock}` : '\nIMPORTANT: Use Google Search to look up real prices for similar items.'}

CRITICAL MATERIAL-BASED PRICING GUIDE (solidarity shop prices):
- Plastic/synthetic items: very cheap. Clothing €0.50-1.50, household items €0.50-2
- Cotton/wool/linen clothing: €1.50-5 depending on condition
- Particle board/MDF/laminate furniture (IKEA-style): €2-8
- Solid hardwood furniture (oak, walnut, pine): €5-50+ depending on size
- Metal items: €1-10 depending on size/weight
- Leather goods: €2-15
- Glass/ceramic: €0.50-5
- Electronics: research the specific model
- Branded items: research the brand, can be worth 2-3x generic

PRICING RULES:
- Use the material guide above as baseline
- Search for similar items to calibrate
- The recommended shop price must be approximately 30% of market value
- ALWAYS provide a price estimate — even a rough one is better than nothing
${historyBlock}
Respond in ${getLanguageName(language)} ONLY with valid JSON (no markdown, no code fences):
{
  "itemName": "descriptive name based on what you see",
  "brand": "brand if visible, otherwise null",
  "category": "${categoryList}",
  "condition": "${conditionStr}",
  "materials": [${materials.map(m => `"${m}"`).join(', ')}],
  "estimatedMarketPrice": number in euros,
  "recommendedShopPrice": number in euros (approximately 30% of market price),
  "confidence": "medium",
  "reasoning": "explanation of how you estimated the price based on materials, condition, and any search results"
}`;

    const response = await callGemini(imageList, prompt, useGeminiGrounding);
    let pricing;
    try {
      pricing = JSON.parse(cleanJson(response));
    } catch (parseErr) {
      console.error('Materials pricing JSON parse failed. Raw:', response.substring(0, 500));
      throw new Error('AI returned an invalid pricing response. Please try again.');
    }

    // Enforce 30% cap
    const marketPrice = pricing.estimatedMarketPrice;
    let shopPrice = pricing.recommendedShopPrice;
    if (marketPrice && shopPrice && shopPrice > marketPrice * 0.35) {
      shopPrice = Math.round(marketPrice * 0.3 * 2) / 2;
    }

    return res.status(200).json({
      singleItem: true,
      needsInput: false,
      ...pricing,
      recommendedShopPrice: shopPrice
    });
  } catch (error) {
    console.error('Materials pricing error:', error);
    const status = error.status || 500;
    const message = error.message || 'Failed to price with materials';
    if (status === 429 || message.includes('429') || message.includes('quota') || message.includes('rate') || message.includes('exhausted')) {
      return res.status(429).json({ error: classifyRateLimit(message, error.geminiDetails) });
    }
    return res.status(status).json({ error: message });
  }
}

async function callGemini(base64Images, prompt, useSearch = false) {
  if (!process.env.GEMINI_API_KEY) {
    const err = new Error('GEMINI_API_KEY is not configured');
    err.status = 500;
    throw err;
  }

  const imagesArray = Array.isArray(base64Images) ? base64Images : [base64Images];
  const imageParts = imagesArray.filter(Boolean).map(data => ({
    inlineData: { mimeType: 'image/jpeg', data }
  }));

  const body = {
    contents: [{
      parts: [
        { text: prompt },
        ...imageParts
      ]
    }]
  };

  // Add Google Search grounding tool when no Custom Search results
  if (useSearch) {
    body.tools = [{
      google_search: {}
    }];
  }

  const maxRetries = 2;
  let lastError;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(`${GEMINI_URL}?key=${process.env.GEMINI_API_KEY}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Referer': process.env.PUBLIC_APP_URL || 'https://love-me-again.vercel.app'
        },
        body: JSON.stringify(body)
      });

      const data = await response.json();

      if (!response.ok) {
        const errMsg = data?.error?.message || JSON.stringify(data);
        const errDetails = data?.error?.details || [];
        console.error(`Gemini API error (attempt ${attempt + 1}): ${response.status} - ${errMsg} | Details: ${JSON.stringify(errDetails)}`);
        const err = new Error(`Gemini API ${response.status}: ${errMsg}`);
        err.status = response.status;
        err.geminiDetails = errDetails;

        // Retry on 429 (rate limit) or 503 (overloaded)
        if ((response.status === 429 || response.status === 503) && attempt < maxRetries) {
          await new Promise(r => setTimeout(r, (attempt + 1) * 2000));
          lastError = err;
          continue;
        }
        throw err;
      }

      if (!data.candidates || !data.candidates[0]?.content?.parts) {
        const reason = data.candidates?.[0]?.finishReason || 'unknown';
        throw new Error(`Gemini returned no content (finishReason: ${reason})`);
      }

      // Extract text from response (may have multiple parts with grounding)
      const parts = data.candidates[0].content.parts;
      const textParts = parts.filter(p => p.text);
      return textParts.map(p => p.text).join('');
    } catch (fetchErr) {
      lastError = fetchErr;
      if (fetchErr.status) throw fetchErr; // Already a Gemini error, don't retry network errors
      if (attempt < maxRetries) {
        console.log(`Gemini fetch failed (attempt ${attempt + 1}), retrying...`);
        await new Promise(r => setTimeout(r, (attempt + 1) * 2000));
        continue;
      }
    }
  }

  throw lastError || new Error('Gemini API call failed after retries');
}

function classifyRateLimit(message, geminiDetails) {
  const msg = message.toLowerCase();
  const resetHour = getResetTimeLocal();

  // 1. Check structured details first (Gemini returns metadata array with quota info)
  if (Array.isArray(geminiDetails)) {
    const allDetails = JSON.stringify(geminiDetails).toLowerCase();
    if (allDetails.includes('per_day') || allDetails.includes('per day') || allDetails.includes('daily') || allDetails.includes('generatecontent')) {
      return `Daily AI quota exhausted (1,500 requests/day). It resets at ${resetHour}. Try again then.`;
    }
    if (allDetails.includes('per_minute') || allDetails.includes('per minute')) {
      return 'Too many requests (15/minute limit). Please wait 1-2 minutes and try again.';
    }
  }

  // 2. Check error message text
  if (msg.includes('per day') || msg.includes('per_day') || msg.includes('daily') || msg.includes('per-day')) {
    return `Daily AI quota exhausted (1,500 requests/day). It resets at ${resetHour}. Try again then.`;
  }
  if (msg.includes('per minute') || msg.includes('per_minute') || msg.includes('per-minute')) {
    return 'Too many requests (15/minute limit). Please wait 1-2 minutes and try again.';
  }

  // 3. RESOURCE_EXHAUSTED without specific period — most likely daily quota
  if (msg.includes('resource') || msg.includes('exhausted') || msg.includes('quota')) {
    return `Daily AI quota exhausted (1,500 requests/day). It resets at ${resetHour}. Try again then.`;
  }

  // 4. Log for future improvement, but still give a specific guess
  console.log('Unclassified rate limit message:', message, '| Details:', JSON.stringify(geminiDetails));
  return 'AI rate limit reached. Please try again later.';
}

function getResetTimeLocal() {
  // Google API quotas reset at midnight Pacific Time (America/Los_Angeles)
  // Convert that to a readable local time for the user (Spain = Europe/Madrid)
  try {
    const now = new Date();
    // Find next midnight PT
    const midnightPT = new Date(now.toLocaleString('en-US', { timeZone: 'America/Los_Angeles' }));
    midnightPT.setDate(midnightPT.getDate() + 1);
    midnightPT.setHours(0, 0, 0, 0);
    // Convert back: get the UTC offset difference
    const resetUTC = new Date(midnightPT.toLocaleString('en-US', { timeZone: 'UTC' }));
    const resetSpain = new Date(resetUTC.toLocaleString('en-US', { timeZone: 'Europe/Madrid' }));
    const hours = resetSpain.getHours();
    return `${hours}:00 (Spain time)`;
  } catch (e) {
    return '9:00 AM (Spain time)';
  }
}

function cleanJson(text) {
  return text.replace(/```json\s*/g, '').replace(/```\s*/g, '').trim();
}

function getLanguageName(code) {
  const names = {
    en: 'English', es: 'Spanish', de: 'German', zh: 'Chinese',
    ar: 'Arabic', ro: 'Romanian', uk: 'Ukrainian', bg: 'Bulgarian',
    hi: 'Hindi', bn: 'Bengali', ur: 'Urdu', tl: 'Tagalog',
    sw: 'Swahili', wo: 'Wolof', ha: 'Hausa',
    ko: 'Korean', ja: 'Japanese', vi: 'Vietnamese', th: 'Thai',
    fr: 'French', it: 'Italian', pt: 'Portuguese', ca: 'Catalan',
    gl: 'Galician', nl: 'Dutch', sv: 'Swedish', da: 'Danish',
    no: 'Norwegian', is: 'Icelandic',
    ru: 'Russian', pl: 'Polish', cs: 'Czech', sk: 'Slovak',
    hr: 'Croatian', sr: 'Serbian', bs: 'Bosnian', sl: 'Slovenian',
    mk: 'Macedonian', be: 'Belarusian',
    lt: 'Lithuanian', lv: 'Latvian',
    fi: 'Finnish', et: 'Estonian', hu: 'Hungarian',
    el: 'Greek', sq: 'Albanian', tr: 'Turkish',
    mt: 'Maltese', ga: 'Irish', cy: 'Welsh', eu: 'Basque'
  };
  return names[code] || 'English';
}
