import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '12mb'
    }
  }
};

const BUCKET = 'event-photos';

export default async function handler(req, res) {
  if (req.method === 'POST') return handleCreate(req, res);
  if (req.method === 'PATCH') return handleUpdate(req, res);
  if (req.method === 'DELETE') return handleDelete(req, res);
  return res.status(405).json({ error: 'Method not allowed' });
}

async function uploadPhotos(photosBase64) {
  const urls = [];
  for (const b64 of photosBase64) {
    if (!b64) continue;
    const raw = typeof b64 === 'string' && b64.startsWith('data:')
      ? b64.split(',')[1]
      : b64;
    const fileName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.jpg`;
    const buffer = Buffer.from(raw, 'base64');

    const { error: uploadError } = await supabase.storage
      .from(BUCKET)
      .upload(fileName, buffer, {
        contentType: 'image/jpeg',
        upsert: false
      });

    if (uploadError) {
      console.error('Event photo upload error:', uploadError);
      throw new Error('Failed to upload photo');
    }

    const { data: urlData } = supabase.storage.from(BUCKET).getPublicUrl(fileName);
    urls.push(urlData.publicUrl);
  }
  return urls;
}

function sanitize(body) {
  const {
    kind, title, description,
    starts_at, ends_at, location,
    capacity, price_eur, organizer, contact, requirements,
    language, status, video_url
  } = body;

  const out = {};
  if (kind !== undefined) out.kind = kind === 'workshop' ? 'workshop' : 'event';
  if (title !== undefined) out.title = title;
  if (description !== undefined) out.description = description || null;
  if (starts_at !== undefined) out.starts_at = starts_at;
  if (ends_at !== undefined) out.ends_at = ends_at || null;
  if (location !== undefined) out.location = location || null;
  if (capacity !== undefined) out.capacity = capacity === '' || capacity == null ? null : parseInt(capacity);
  if (price_eur !== undefined) out.price_eur = price_eur === '' || price_eur == null ? null : parseFloat(price_eur);
  if (organizer !== undefined) out.organizer = organizer || null;
  if (contact !== undefined) out.contact = contact || null;
  if (requirements !== undefined) out.requirements = requirements || null;
  if (language !== undefined) out.language = language || 'es';
  if (status !== undefined) out.status = status || 'published';
  if (video_url !== undefined) out.video_url = video_url || null;
  return out;
}

async function handleCreate(req, res) {
  try {
    const { photos = [], photo_urls = [], ...rest } = req.body || {};
    const fields = sanitize(rest);

    if (!fields.title || !fields.starts_at || !fields.kind) {
      return res.status(400).json({ error: 'title, starts_at and kind are required' });
    }

    let uploaded = [];
    if (Array.isArray(photos) && photos.length > 0) {
      uploaded = await uploadPhotos(photos);
    }

    const merged = [...(Array.isArray(photo_urls) ? photo_urls : []), ...uploaded];

    const { data, error } = await supabase
      .from('events')
      .insert({ ...fields, photo_urls: merged })
      .select()
      .single();

    if (error) {
      console.error('Event insert error:', error);
      return res.status(500).json({ error: 'Failed to create event' });
    }

    return res.status(201).json(data);
  } catch (err) {
    console.error('Create event error:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
}

async function handleUpdate(req, res) {
  try {
    const { id, photos, photo_urls, ...rest } = req.body || {};
    if (!id) return res.status(400).json({ error: 'Event id is required' });

    const updates = sanitize(rest);
    updates.updated_at = new Date().toISOString();

    let finalUrls = null;
    if (Array.isArray(photo_urls)) finalUrls = [...photo_urls];
    if (Array.isArray(photos) && photos.length > 0) {
      const uploaded = await uploadPhotos(photos);
      finalUrls = [...(finalUrls || []), ...uploaded];
    }
    if (finalUrls !== null) updates.photo_urls = finalUrls;

    const { data, error } = await supabase
      .from('events')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      console.error('Event update error:', error);
      return res.status(500).json({ error: 'Failed to update event' });
    }

    return res.status(200).json(data);
  } catch (err) {
    console.error('Update event error:', err);
    return res.status(500).json({ error: err.message || 'Internal server error' });
  }
}

async function handleDelete(req, res) {
  try {
    const { id } = req.body || {};
    if (!id) return res.status(400).json({ error: 'Event id is required' });

    const { data: existing } = await supabase
      .from('events')
      .select('photo_urls')
      .eq('id', id)
      .single();

    const { error } = await supabase
      .from('events')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Event delete error:', error);
      return res.status(500).json({ error: 'Failed to delete event' });
    }

    if (existing && Array.isArray(existing.photo_urls) && existing.photo_urls.length > 0) {
      const fileNames = existing.photo_urls
        .map(u => (u || '').split('/').pop())
        .filter(Boolean);
      if (fileNames.length > 0) {
        await supabase.storage.from(BUCKET).remove(fileNames);
      }
    }

    return res.status(200).json({ success: true });
  } catch (err) {
    console.error('Delete event error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
