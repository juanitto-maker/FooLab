import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY
);

export const config = {
  api: {
    bodyParser: {
      sizeLimit: '12mb'
    }
  }
};

const MAX_PHOTOS = 5;

export default async function handler(req, res) {
  if (req.method === 'POST') {
    return handleCreate(req, res);
  }
  if (req.method === 'PATCH') {
    return handleUpdate(req, res);
  }
  if (req.method === 'DELETE') {
    return handleDelete(req, res);
  }
  return res.status(405).json({ error: 'Method not allowed' });
}

async function uploadPhoto(base64) {
  const fileName = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}.jpg`;
  const buffer = Buffer.from(base64, 'base64');

  const { error: uploadError } = await supabase.storage
    .from('item-photos')
    .upload(fileName, buffer, {
      contentType: 'image/jpeg',
      upsert: false
    });

  if (uploadError) {
    throw new Error(uploadError.message || 'Upload failed');
  }

  const { data: urlData } = supabase.storage
    .from('item-photos')
    .getPublicUrl(fileName);

  return urlData.publicUrl;
}

async function handleCreate(req, res) {
  try {
    const {
      photo, photos, description, category, brand, condition,
      ai_suggested_price, final_price, language, ai_reasoning, ai_confidence
    } = req.body;

    // Normalize: accept either `photo` (single base64) or `photos` (array of base64)
    let photoList = [];
    if (Array.isArray(photos) && photos.length > 0) {
      photoList = photos.filter(Boolean).slice(0, MAX_PHOTOS);
    } else if (photo) {
      photoList = [photo];
    }

    if (photoList.length === 0 || !description || !category) {
      return res.status(400).json({ error: 'photo, description, and category are required' });
    }

    // Upload all photos sequentially (sequential avoids bursting Supabase limits)
    const uploadedUrls = [];
    for (const p of photoList) {
      try {
        const url = await uploadPhoto(p);
        uploadedUrls.push(url);
      } catch (err) {
        console.error('Photo upload error:', err);
        // Continue with remaining — partial upload is better than none
      }
    }

    if (uploadedUrls.length === 0) {
      return res.status(500).json({ error: 'Failed to upload photos' });
    }

    const primaryUrl = uploadedUrls[0];

    // Try insert with photo_urls column; fall back to single-photo insert if column missing
    const baseRow = {
      photo_url: primaryUrl,
      description,
      category,
      brand: brand || null,
      condition: condition || null,
      ai_suggested_price: ai_suggested_price || null,
      final_price: final_price || null,
      language: language || 'es',
      ai_reasoning: ai_reasoning || null,
      ai_confidence: ai_confidence || null,
      status: 'available'
    };

    let { data, error } = await supabase
      .from('items')
      .insert({ ...baseRow, photo_urls: uploadedUrls })
      .select()
      .single();

    if (error && /photo_urls/i.test(error.message || '')) {
      console.warn('photo_urls column missing, retrying without it. Run /api/migrate-photo-urls to add it.');
      const retry = await supabase
        .from('items')
        .insert(baseRow)
        .select()
        .single();
      data = retry.data;
      error = retry.error;
    }

    if (error) {
      console.error('Insert error:', error);
      return res.status(500).json({ error: 'Failed to create item' });
    }

    // Ensure response always carries the full photos array
    if (data && !data.photo_urls) {
      data.photo_urls = uploadedUrls;
    }

    return res.status(201).json(data);
  } catch (error) {
    console.error('Create item error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function handleUpdate(req, res) {
  try {
    const { id, ...updates } = req.body;

    if (!id) {
      return res.status(400).json({ error: 'Item id is required' });
    }

    // If marking as sold, set sold_at timestamp
    if (updates.status === 'sold') {
      updates.sold_at = new Date().toISOString();
    }

    const { data, error } = await supabase
      .from('items')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    if (error) {
      // If the error is about sold_price column not existing, retry without it
      if (updates.sold_price !== undefined) {
        console.warn('Update failed with sold_price, retrying without it:', error.message);
        const { sold_price, ...updatesWithoutSoldPrice } = updates;
        const { data: data2, error: error2 } = await supabase
          .from('items')
          .update(updatesWithoutSoldPrice)
          .eq('id', id)
          .select()
          .single();

        if (error2) {
          console.error('Update error (retry):', error2);
          return res.status(500).json({ error: 'Failed to update item' });
        }

        // Try to add the sold_price column and set it
        try {
          await supabase.rpc('exec_sql', {
            query: 'ALTER TABLE items ADD COLUMN IF NOT EXISTS sold_price decimal(10,2);'
          });
          await supabase
            .from('items')
            .update({ sold_price })
            .eq('id', id);
        } catch (e) {
          console.warn('Could not set sold_price (column may not exist):', e.message);
        }

        return res.status(200).json(data2);
      }

      console.error('Update error:', error);
      return res.status(500).json({ error: 'Failed to update item' });
    }

    return res.status(200).json(data);
  } catch (error) {
    console.error('Update item error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

async function handleDelete(req, res) {
  try {
    const { id } = req.body;

    if (!id) {
      return res.status(400).json({ error: 'Item id is required' });
    }

    // Get item to find photo filenames for cleanup
    const { data: item } = await supabase
      .from('items')
      .select('photo_url, photo_urls')
      .eq('id', id)
      .single();

    // Delete the item from database
    const { error } = await supabase
      .from('items')
      .delete()
      .eq('id', id);

    if (error) {
      console.error('Delete error:', error);
      return res.status(500).json({ error: 'Failed to delete item' });
    }

    // Try to delete every associated photo from storage
    if (item) {
      const urls = [];
      if (Array.isArray(item.photo_urls) && item.photo_urls.length > 0) {
        urls.push(...item.photo_urls);
      } else if (item.photo_url) {
        urls.push(item.photo_url);
      }
      const fileNames = urls.map(u => u && u.split('/').pop()).filter(Boolean);
      if (fileNames.length > 0) {
        await supabase.storage.from('item-photos').remove(fileNames);
      }
    }

    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('Delete item error:', error);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
